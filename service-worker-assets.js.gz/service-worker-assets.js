self.assetsManifest = {
  "version": "biE7Odx2",
  "assets": [
    {
      "hash": "sha256-e3zNUcefZYF/1+Xl7aOCw3kEkS3+S+JWcTqE17bxyMs=",
      "url": "CyberShelf.styles.css"
    },
    {
      "hash": "sha256-itxgC9CUXgA0s57EK2bjpHhRABlrtO8ndt+ThYI7Lus=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-USfz9dlGhieh6X3j+zNSBR0CkWQSrBwnXgg6dP3yKic=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-0WS9OUYlBUzlWGN3JgKYDU5IsiNXBdgOYls8WBXTwxI=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-EqekAACIvGn+BzEQNyKtrBnMxa4TJKka4nvfJCxWI1s=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-oT0AFvDMScxXr9NJOSkkExxIjxdlCW54rFaObRj8168=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-ONPJMnz+8ymywSQcf2SNu1/JyLjZ82vh63Aw4W837XA=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-e+ez+HsLmQBtb1rJ/dmNL5wzbeRwbKdfvhwKqSWI7aI=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-0l/BVYcWLkQUmSombv/xeg/2EID0oor31p+4I/GETW8=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-EYr43ww4zQp88+PiLhoJiz6WhsP5Etm4YPxX7ukp/ZA=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-LUkl9GDNHWfNm5WKFHPAMLGKtrMdSQYO2FCmGz0VOSw=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-G1vX7rSefBwvqDj8sQkCb2s/AMzSPRsrpvhZ50fv3vk=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-W3my/u11XGlNQgdRGAB9SfHGevH8Tz8JJGOGF18lp8I=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-GH+pZhFw/ttZyUlYERg5MymsNmdCDxNHlRxc0Zg/XvE=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-RrbfvEKPx2i+7DwnVAwIawaNmNdY16z+2opp+wyYy+A=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-IbXcLhCGLLiwfZP0XoE4LwogjxJpuCsxt2bLxYtsK1U=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-FQFhpNMcxu6iJB48WEAOIbI54wb4GZw8eUS5jc5ZS9M=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-IqebHpObFfJwt35zLUkNRhwRRPu43+GjGYwuuv80vsQ=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-7Ybjf86BTTZE8vtvQDMit4Qziy+JgVQWaaTvnizcl2k=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-J3xX0NyH4GX7TFMBl2jv3+YQCKaS31liM8LIyElsYlU=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-ES+IU6suO8xnaTREbUqzWHMFfHJ9OTq4m9QIWqffK5k=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-KgNWfaF1iIh/HoGqRO2a+o1ljg8JZRxQ+JNQjHbZeNs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-4yq2FvfFqifIk1NPw343s3q2ZGM0dHNJrH4fux869Uc=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-sRLBWmFIh1BpCYWUffUu/wQPvd4HqTzuBTc6ATVYdDI=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-vb1efzyvxmikTSg3TlZbLXgurTgBDWHGssyeUtq0bSs=",
      "url": "_framework/AngleSharp.Css.3sta13sd5v.wasm"
    },
    {
      "hash": "sha256-7n1bRur1WWoyULdRSy3endC+3Ggpl7g1R19Rg8t+9wY=",
      "url": "_framework/AngleSharp.ivgi0qnhli.wasm"
    },
    {
      "hash": "sha256-/WvJjJZyShTIgkXvpC/sfgOh2G7Cq2+VDXqe1J+PLrk=",
      "url": "_framework/CyberShelf.n7zz39ty3x.wasm"
    },
    {
      "hash": "sha256-q9PppVVqoaBAYMx58FQjJkfEcMyHM/bu/S9DAKzMPEg=",
      "url": "_framework/Fluxor.3ezyo5aogq.wasm"
    },
    {
      "hash": "sha256-36Ot7Tl90KT4vrStA0Lrgaa2OLhA9ebdQDqYSvl7DDg=",
      "url": "_framework/Fluxor.Blazor.Web.5zn7zddj3v.wasm"
    },
    {
      "hash": "sha256-MqKrZwpPDUTBwo8bRwPpbjk1YStxbdFPNkDu9NQmipo=",
      "url": "_framework/HtmlSanitizer.mucfvkykdc.wasm"
    },
    {
      "hash": "sha256-Q41XHbk/rXRrx5apCP6Qn+O01M2G22p8qEwmyQVx/Xk=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.bmep3lq258.wasm"
    },
    {
      "hash": "sha256-Pk8UN/DeC7eatOuFGtTCMyA/jMAFmVdTYbd4x7T64Zc=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.ys3ey12e26.wasm"
    },
    {
      "hash": "sha256-LpIDvM3vKVDqCIrWCj58aPxox/TKHVhOG8Bs0vK5eXE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.ygrjwbvlrn.wasm"
    },
    {
      "hash": "sha256-9xfrCVPKgO36o0rP+L4/N15UCM8pSVKsFaFzDuFaCHk=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.xmxb1qikuh.wasm"
    },
    {
      "hash": "sha256-TEad/jakAtf2PM0ViPlJql520F5gdYiL/jxxTEmVCwQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.w1fanqrerc.wasm"
    },
    {
      "hash": "sha256-UF8DfMUzzoZExYSsDhwkeNuLfZQE+RYKQv3GUnD0w+Y=",
      "url": "_framework/Microsoft.AspNetCore.Components.gsd2xvpyhb.wasm"
    },
    {
      "hash": "sha256-oIqKGHI5XCL0NWWadu+BrIEVj4vdX22pzrtWdtRhSM4=",
      "url": "_framework/Microsoft.AspNetCore.Connections.Abstractions.8ypo4680hh.wasm"
    },
    {
      "hash": "sha256-EobXrW2V/LUTCqODlh1BX80hpsr2DffhjXQhjUhiBTQ=",
      "url": "_framework/Microsoft.AspNetCore.Http.Connections.Client.e1eoh2bmi3.wasm"
    },
    {
      "hash": "sha256-Yz50z0QAq/L65OcyOQnRQzvAt1eyCnEXPgGaLZkoQGs=",
      "url": "_framework/Microsoft.AspNetCore.Http.Connections.Common.1bdpqy5lbp.wasm"
    },
    {
      "hash": "sha256-ZSXv/xlw+ohVALOOYihI5bfIp7+ES0chART1Cg4L6Ug=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.di5ixinmlr.wasm"
    },
    {
      "hash": "sha256-Vd/MHnY5uxxhkDTmmPkLnBFwVa3HZMrXsJqWzLLpyQc=",
      "url": "_framework/Microsoft.AspNetCore.SignalR.Client.9n185ww2w1.wasm"
    },
    {
      "hash": "sha256-NyVXQX4vL0TUCnHOQ2M1Onj8tmSo/ADl10pUJQl4Mug=",
      "url": "_framework/Microsoft.AspNetCore.SignalR.Client.Core.p8xawdezxb.wasm"
    },
    {
      "hash": "sha256-7Cl9oTWOaphZOeBVI+N/DeaG9JUblp2wMxtEvdLgArE=",
      "url": "_framework/Microsoft.AspNetCore.SignalR.Common.sghipedi2l.wasm"
    },
    {
      "hash": "sha256-GeqZP4iu0/c2HpezAxRuIrQkbFcTohnl94ClSBj8PAE=",
      "url": "_framework/Microsoft.AspNetCore.SignalR.Protocols.Json.p86iuj7ioc.wasm"
    },
    {
      "hash": "sha256-WOkSh8YqGn7JKMsWPDMdwa2UOQCjoInHngubrZQM+jU=",
      "url": "_framework/Microsoft.CSharp.8gipt46v15.wasm"
    },
    {
      "hash": "sha256-KWh1EQH0ycROTxIgcltPW951tPUxrzzX3lZVN1v8+L0=",
      "url": "_framework/Microsoft.Extensions.Configuration.9o81i1tzht.wasm"
    },
    {
      "hash": "sha256-W5FfNo5sisGk8PUWhIGWjnU/MQPqy4WaSImkTZWIPso=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h17wbydgyf.wasm"
    },
    {
      "hash": "sha256-Exo6P1fUo9sLIXaI485MxTNmj2DpDRmVKQ3AW99ChAw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.3g5ebf4tl2.wasm"
    },
    {
      "hash": "sha256-NjAIjIQlITJK5e/1cNjeMLBSuW2yXbc3mfYPnlQU0WU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ixktlrimdt.wasm"
    },
    {
      "hash": "sha256-PWTiOHNTVbGVKHtDcGGtipr6if41b8TkyJHJ0G24GXY=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.bugm5apaop.wasm"
    },
    {
      "hash": "sha256-/ygxEF8Hjga4WgI+B2dSftrYejRCWV7gMGuDNF6UVEk=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.hgrsdcsjdv.wasm"
    },
    {
      "hash": "sha256-ZMzg83WMKMbfhQAvytfiNQMTyXPPUeToG0RXEjWfbQg=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.c44fh0grzf.wasm"
    },
    {
      "hash": "sha256-DnCWuYSqfnzpDWkW8C+DyIFbBr2mjmkKJmT9FVFxKLo=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.u9xe0429mc.wasm"
    },
    {
      "hash": "sha256-Ss/6lTE+1E7g77gAmln1y+EQ2Ws3CNNMJL1rNSgBVK8=",
      "url": "_framework/Microsoft.Extensions.Features.mcjfdpv82v.wasm"
    },
    {
      "hash": "sha256-8E5dE53aQ5sjCBf3ycMlW01ArS7+/oB0b3q+ORSDEe0=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.omg3crgcso.wasm"
    },
    {
      "hash": "sha256-cPVfX0ssGEK6Wi4Y8vRe3Vu6J3OwqvcCMhafUqLk5JU=",
      "url": "_framework/Microsoft.Extensions.Localization.sxhvuspdhn.wasm"
    },
    {
      "hash": "sha256-JQrT6klVQgULsMJzkEQbauSIqImfOlfpo5fJQkSqKqc=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.lcajvk04px.wasm"
    },
    {
      "hash": "sha256-MkX7cCEllAS97UwS2KBWg9fi5zvOl6QLKt008ZLjjpM=",
      "url": "_framework/Microsoft.Extensions.Logging.e4zgpb6qav.wasm"
    },
    {
      "hash": "sha256-S4nbFiC+aNefj9FuetM/mpwdRP34td5i/HGHoNPD87Q=",
      "url": "_framework/Microsoft.Extensions.Options.lkhzfdbv9e.wasm"
    },
    {
      "hash": "sha256-ymLJ18O0TWi69zlDhVo+NpMt34Z3v1+9qEyGdf3sJFI=",
      "url": "_framework/Microsoft.Extensions.Primitives.yxjt7vtatl.wasm"
    },
    {
      "hash": "sha256-Xcxd+z/8v1MjYI/6IsNgJ46ifV38aKmiGyz4RR+L0ms=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ydn64ly88.wasm"
    },
    {
      "hash": "sha256-ogoUNHwq8mr+C28TA7/euzi2rNSvPenaN6+X6F14Vzs=",
      "url": "_framework/Microsoft.JSInterop.irk9g1jt11.wasm"
    },
    {
      "hash": "sha256-Vzp1unE7XLoEN1xoUrKWC1it/PVAQFJ4KRI5ISjMk9o=",
      "url": "_framework/Radzen.Blazor.brgyl7sl7g.wasm"
    },
    {
      "hash": "sha256-7cQCdXEYK6sDyYUaWsQl3OEB2jXZyFufrwZmSKHyTKM=",
      "url": "_framework/System.Collections.Concurrent.91c4zv9pdn.wasm"
    },
    {
      "hash": "sha256-lNGbEuZlXlQMjcIDaL/L6TYFBKn6VhwjVBKx746qtK8=",
      "url": "_framework/System.Collections.Immutable.gpw00r6umg.wasm"
    },
    {
      "hash": "sha256-7c1BMCBEYB0zsmb1njvP5YyJTpHJSY6tu2UT0u5vseE=",
      "url": "_framework/System.Collections.NonGeneric.xvrf7vlozt.wasm"
    },
    {
      "hash": "sha256-n8NOD3yrGBmBYD7rUS9LyI72W8C/yrCfwI7vTHXb2LQ=",
      "url": "_framework/System.Collections.Specialized.txmxmtm6kv.wasm"
    },
    {
      "hash": "sha256-+u13CGiyTptFh3NjptmAsNF1bk1tuztslLMWlWJWFDY=",
      "url": "_framework/System.Collections.mpq34k37tr.wasm"
    },
    {
      "hash": "sha256-e5fTQl1rPXMlXGZqStM5bvN9f2eY4J469jgsvXVIrb4=",
      "url": "_framework/System.ComponentModel.Annotations.vn6fwqkzom.wasm"
    },
    {
      "hash": "sha256-xoKxYUCRKs636h8bZ2fMS1zEg8nviGYpFyzlzLbkpmI=",
      "url": "_framework/System.ComponentModel.Primitives.agbtinp8h7.wasm"
    },
    {
      "hash": "sha256-mXY2RApGRAItL0KlpQPGj6rouGIrUZC1q/cua/ZdRX4=",
      "url": "_framework/System.ComponentModel.TypeConverter.lpo6on2vi7.wasm"
    },
    {
      "hash": "sha256-G/6EwBzWPMxU/4/py+wFnYln9lhcjEBQNpoWxkdNym4=",
      "url": "_framework/System.ComponentModel.vvuj3malmy.wasm"
    },
    {
      "hash": "sha256-U+4uWvP8NvI1ysD4ieKrzlzpw0G9xH3jBVBX4kcDoho=",
      "url": "_framework/System.Console.njpse0b0uc.wasm"
    },
    {
      "hash": "sha256-6tqPDxv8LgQtZVuDu7pCBH2aS8fKRZvrTKeOfByqp4k=",
      "url": "_framework/System.Core.69mx0zocjz.wasm"
    },
    {
      "hash": "sha256-TLbNqTb4JQ3RXL8p89PUmBGYka+5ml6wiC+Vw6X46hk=",
      "url": "_framework/System.Data.Common.kk5a3nz9i6.wasm"
    },
    {
      "hash": "sha256-yadWOYbWGOTF/dcc4jOH25m9FmeIo7BBlUygsCCkid0=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.j9y302wh1j.wasm"
    },
    {
      "hash": "sha256-pD9Zvy5LbVir0BSnnFx7GtXQYIeMbkC2JWG+oXhPGd8=",
      "url": "_framework/System.Drawing.4q3qj66otc.wasm"
    },
    {
      "hash": "sha256-WYbuJ2NFqttZBGfOpRo+xoMbQaizCX9SzxM8firgDlU=",
      "url": "_framework/System.Drawing.Primitives.9w91me9toy.wasm"
    },
    {
      "hash": "sha256-6Mm8HKUDk39v4IqyBMPxIK2DsaKjLQPBC+sq8NCg6rI=",
      "url": "_framework/System.IO.Compression.k9lt5t0s4k.wasm"
    },
    {
      "hash": "sha256-kdEaPLOlFg+IBEL6uZCCNZMLkxbEPm1OAQdmCHLTbCc=",
      "url": "_framework/System.IO.Pipelines.vk8g76um1e.wasm"
    },
    {
      "hash": "sha256-DKfhCFEuH/E0ff1cF4MKdjbBgdpf3kvagNkQD5UUI88=",
      "url": "_framework/System.Linq.Expressions.kax6xmecbf.wasm"
    },
    {
      "hash": "sha256-DkzMSUDEnYa3l7fyY93nEMOdhtcG2YvgPlb8X7ciuac=",
      "url": "_framework/System.Linq.Queryable.yk0kobxtrc.wasm"
    },
    {
      "hash": "sha256-xcClaKA7rIGBtsL7GLT76zZ5Tud27yJlxbD+z0NwWW8=",
      "url": "_framework/System.Linq.b8pu018hrt.wasm"
    },
    {
      "hash": "sha256-8X8D/A5XpPesEuPvrkIv0LU9jHd/DH+Z2QAKk/F5z/w=",
      "url": "_framework/System.Memory.zj48f6z1h2.wasm"
    },
    {
      "hash": "sha256-HHy+X1E5JpwHob2vkSVUFU68pYhAZWSH94+7V/7NPYE=",
      "url": "_framework/System.Net.Http.8xnwz2bhd7.wasm"
    },
    {
      "hash": "sha256-1VM4sttSziEd8bjcLLCuL510mwjw91qr3Vu3yEM3h8M=",
      "url": "_framework/System.Net.Http.Json.1xv1cka4fk.wasm"
    },
    {
      "hash": "sha256-+FMzUBCP1xWYgYdgmxWOrm2l4jGat8IU0b1nFwQuxn0=",
      "url": "_framework/System.Net.Primitives.cns07x9sv1.wasm"
    },
    {
      "hash": "sha256-Ei50ZEJ0v2A9NV+8iuk1gocBwW6KLEf8IwsF6Py6rBk=",
      "url": "_framework/System.Net.Requests.6v7purlf4j.wasm"
    },
    {
      "hash": "sha256-PTEon/mtRvxBJDlx58rnAmOSSUepaDaOaEMYRcKWJyA=",
      "url": "_framework/System.Net.Security.hnzza2stqb.wasm"
    },
    {
      "hash": "sha256-eQLsCnAGaUMGLI6qzxvJ266IPHyAjhka3VJZ4gS5Wic=",
      "url": "_framework/System.Net.ServerSentEvents.5p37ofk4aw.wasm"
    },
    {
      "hash": "sha256-YyZyIquUwn8ZKli/Fms3533JUJHS7afuS5M58dFcYMo=",
      "url": "_framework/System.Net.WebHeaderCollection.zggssa66ip.wasm"
    },
    {
      "hash": "sha256-lH7ImjUonkt9CJ3avTNB2DJ1L1eU63NjtO60L+OXp6k=",
      "url": "_framework/System.Net.WebSockets.8bs5k7l401.wasm"
    },
    {
      "hash": "sha256-z985l7fBbIfui6eRwaVJya8RHIwtHiBgm3wKR/HyY6o=",
      "url": "_framework/System.Net.WebSockets.Client.lbt3db7viz.wasm"
    },
    {
      "hash": "sha256-plcrPcEwcSu20nIwrv9ZTZEvsNXx2gYo4mRQP312bNo=",
      "url": "_framework/System.Numerics.Vectors.mpsc4ywdkn.wasm"
    },
    {
      "hash": "sha256-9wBujB+ZLVvh3p0ZcKZ7wZ1hVJg+hMm3bMT5CP0cWYs=",
      "url": "_framework/System.ObjectModel.ldq2ds3fa3.wasm"
    },
    {
      "hash": "sha256-T7mWrEW7dc7vsTZV1ZyR7jR0tqxV2hDxL5H7IViKsuw=",
      "url": "_framework/System.Private.CoreLib.pmkx0og4kl.wasm"
    },
    {
      "hash": "sha256-H+P6f8sI+vgoyVIa5kjeC5LNc1ZmMvWUv14BnPHEMMY=",
      "url": "_framework/System.Private.Uri.v00o9hoz2k.wasm"
    },
    {
      "hash": "sha256-9wMa3qWTdZVgBXIqwjgQDfcB+UHYNtf6R5yonrexKD4=",
      "url": "_framework/System.Private.Xml.Linq.b3sv0h0ia1.wasm"
    },
    {
      "hash": "sha256-ml4ETreifM7xPfEOP6LnxeEamsFj4eLOkqiwaql2UQg=",
      "url": "_framework/System.Private.Xml.uuddu3p7da.wasm"
    },
    {
      "hash": "sha256-ADwVh2CxWm0iO/rnJBn+ePDnMggqFrjf8/QdvLOjZwc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.knrgwrqxog.wasm"
    },
    {
      "hash": "sha256-3r1UTwoxFA6w/bRvZhSPZdn5oQSMN3mQfaWImM3XCGo=",
      "url": "_framework/System.Reflection.Emit.mn176mar7p.wasm"
    },
    {
      "hash": "sha256-7Bw1sNGIBmW5LAauS9CP1ixKUAhXda/bTarwtiIXaag=",
      "url": "_framework/System.Reflection.Primitives.wp31qs1bml.wasm"
    },
    {
      "hash": "sha256-qBy+4LgXGyP5TTj4t4cTt2PFpWmXKRTI/D3R7k0kIoE=",
      "url": "_framework/System.Runtime.4hfg1w92cu.wasm"
    },
    {
      "hash": "sha256-by1UpyjwoXy1zAeT31stXvlD3M5dd2bFDomF+2u1EeY=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.x4uktc5jcw.wasm"
    },
    {
      "hash": "sha256-jItyf07BQiHuk/dd+9ol08DeM/6KIY+QMO598PW8c1A=",
      "url": "_framework/System.Runtime.InteropServices.sqnltnlnqh.wasm"
    },
    {
      "hash": "sha256-Y4Tw3nmRD4khUzTTcc3Uud4xwMWN0kwXi0xIWQP++XY=",
      "url": "_framework/System.Security.Claims.7jr48mcdo4.wasm"
    },
    {
      "hash": "sha256-KXp7g9uUlCzlVSWN5Y0cmToW3xZCd4lKLv2dkNM4vo8=",
      "url": "_framework/System.Security.Cryptography.nk7yjuclmw.wasm"
    },
    {
      "hash": "sha256-ZEeCNxLy6wIM9j+KPK6NWmMyFffz4yPB6toQP72CG8c=",
      "url": "_framework/System.Text.Encoding.CodePages.48gpt7faa9.wasm"
    },
    {
      "hash": "sha256-fQ8obTMWjSGFjfcCRghC6SqT43PRhrw++9xYGIANBwk=",
      "url": "_framework/System.Text.Encoding.Extensions.7jx7v3ecqo.wasm"
    },
    {
      "hash": "sha256-wiSJ6x9QNVgsRnEbHfsiITgSvDM7NZUH0L/JilD093w=",
      "url": "_framework/System.Text.Encodings.Web.mf9wh7gopl.wasm"
    },
    {
      "hash": "sha256-KLYcea1f8A09p/PGdAskk3D22FeyWnhMR//m6f8ZYQw=",
      "url": "_framework/System.Text.Json.kx7giuqojh.wasm"
    },
    {
      "hash": "sha256-rZ+hsWwQeFp/rXyAtQMNmiz89jlXwZwmCf3clOlFUaE=",
      "url": "_framework/System.Text.RegularExpressions.la7fl6gr3i.wasm"
    },
    {
      "hash": "sha256-jbaUl7dxdthXZd6QM8NY3l5iBJQ8AUHIZ/xTQqrjy80=",
      "url": "_framework/System.Threading.Channels.d4vkopcwg2.wasm"
    },
    {
      "hash": "sha256-shlWe83JdBCqOAfA5vx8p98jphDeq785g4zAsMwlwEs=",
      "url": "_framework/System.Threading.ijp8ryvgn6.wasm"
    },
    {
      "hash": "sha256-Vck8BP1Lv1QnlHlYrmhXzSTfF/qBEtF68MtuJnK/Lpw=",
      "url": "_framework/System.Web.HttpUtility.54w7790oyf.wasm"
    },
    {
      "hash": "sha256-ychfeUH0ggf8nxM3GDZvGyM5rfO3tpXNJnb5MepaEKw=",
      "url": "_framework/System.Xml.Linq.3dip6ic8mi.wasm"
    },
    {
      "hash": "sha256-H1zm4NiExekrYyFpkjwwWY02PA/8S3G/v9+2N7mTC/U=",
      "url": "_framework/System.Xml.XDocument.f8nasri302.wasm"
    },
    {
      "hash": "sha256-QZM96Sbw2BYre4bcT9tJXUPU/9h0LdgAPwGMigVXC8g=",
      "url": "_framework/System.x4983syfn1.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-BtOuBiMdjIKtQf48kCuuHKlws++sq25EjUlFToUCujU=",
      "url": "_framework/de/Radzen.Blazor.resources.69frnodk0g.wasm"
    },
    {
      "hash": "sha256-fXHCez8WgHuoFxo7sgAtexzuh7fR7h5OZCXq/DsEQj0=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-jvnZMjejI5ysLZeBvW96mJdF8CE/j4XTdKCPzmRHG1M=",
      "url": "_framework/dotnet.native.ay6x5009eg.wasm"
    },
    {
      "hash": "sha256-A1labT5SXTlEoelZ96LFb0Pb04ubwsi8EcdS9RG7LYs=",
      "url": "_framework/dotnet.native.z49vxemcj2.js"
    },
    {
      "hash": "sha256-YyudibIWETMKrLb+nAZdJ+xDY7HY6BWf6s32UAdcvCU=",
      "url": "_framework/dotnet.runtime.r2kbxkuujc.js"
    },
    {
      "hash": "sha256-ChnlwJU32O6VYUqskFWLskWFwzvHRgwGqp0W26LaGyo=",
      "url": "_framework/es/Radzen.Blazor.resources.yhrzxgfaxe.wasm"
    },
    {
      "hash": "sha256-Lbr4MMrdZiEtFDXqDt/CgF6Ty4HmaBXKadnHRICPJmE=",
      "url": "_framework/fr/Radzen.Blazor.resources.5u7mtnn65u.wasm"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-oEDZVmepTudkIH970klKidk1nHhQ5yc22MBmBIpVSdA=",
      "url": "_framework/it/Radzen.Blazor.resources.8mgyok5a7p.wasm"
    },
    {
      "hash": "sha256-ouh74NtlxLLrtu10F85W3lpDjWrwQVc39N5pPgFD7W8=",
      "url": "_framework/ja/Radzen.Blazor.resources.qp4qhjubvx.wasm"
    },
    {
      "hash": "sha256-uaWX4vU0Whs+vY+teI0+Ch1mK7zAbom11kpsH5QKwdc=",
      "url": "_framework/ru/CyberShelf.resources.90fnyanvh8.wasm"
    },
    {
      "hash": "sha256-Fs/DJ7hZHYllMX18MqfNODd8WndkrJSSRtSkfsHleSE=",
      "url": "_welcome/bg.png"
    },
    {
      "hash": "sha256-pLL8BGIXSBCI8Us9oblGIp7iCGJD4i00OY3skwbvNMc=",
      "url": "_welcome/logo.svg"
    },
    {
      "hash": "sha256-7yXM3wJQCCjrB7CkiRsJveDBhqGIUJYIgGCrL4oybRg=",
      "url": "_welcome/welcome.css"
    },
    {
      "hash": "sha256-7c2REEaWXMRIL91NQr/dBp81g7MkeC2u3GKU62ebXrs=",
      "url": "_welcome/welcome.js"
    },
    {
      "hash": "sha256-B8ybJUrVYNGuGwFspPzQpZxEvov24W+ZRFU4FeNH7I8=",
      "url": "appsettings.CyberShelfCom.json"
    },
    {
      "hash": "sha256-5OZ1UGOvfdw8x/5G/XAh+QoDKkBZkjLv8JoNa/vXs8I=",
      "url": "appsettings.Development.json"
    },
    {
      "hash": "sha256-LH8hLfHEUfIL1w3Or3TSwm0S2km4TQiHwk0zt9m61k4=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-nqgz38BzEuFd/Rh5vGSz/gIq4zYFkxKoGYN6+IeEUes=",
      "url": "assets/about/egor-avatar-square.png"
    },
    {
      "hash": "sha256-ykKcE46lCtVmU117HctNJ1cGRA7lLd6NGQiqb2dQ10M=",
      "url": "assets/about/grigory-avatar-square.png"
    },
    {
      "hash": "sha256-9zB85X8JGJ2Xv1RRXZdvMSMd+JOeXGvWXyGrXKwwlZo=",
      "url": "assets/about/logo-neostandart.png"
    },
    {
      "hash": "sha256-0oaNqnXVHlELgtvglOnqqlNhKavgYCgXyM1FcdiRZlc=",
      "url": "assets/about/logo-uppercode.svg"
    },
    {
      "hash": "sha256-g8b+9rlkvvzoGNqSFdG5ILNWp4+R4h0pMC60Mge4RzI=",
      "url": "assets/countries/countries-en.json"
    },
    {
      "hash": "sha256-jX3YaIBikQ0GzKwueRqkPOi2JWMZzr9zDM2iFkj6aaI=",
      "url": "assets/favicon/favicon.ico"
    },
    {
      "hash": "sha256-8CZK/OvxxIrj0vw/I2oF1YgWvRS43K8chz2AxO1UDcc=",
      "url": "assets/favicon/favicon.png"
    },
    {
      "hash": "sha256-4pm33U7hjP2NgqmRn2li6b5ui1iX6in80jwcbRoVqI0=",
      "url": "assets/h5p-player/core-fix.js"
    },
    {
      "hash": "sha256-tKUIpR3H2rXJ2walt/DWFzmEwtQ4djgPqt5t3ituybM=",
      "url": "assets/h5p-player/player.html"
    },
    {
      "hash": "sha256-Q/uAW1r8RQo5bFqfZvHtnqqju6dTokmjfdai9IleCos=",
      "url": "assets/h5p-player/strings/en.json"
    },
    {
      "hash": "sha256-PTJUDpSsP4lMnpWX0lOr6k+4Y8FuPkukr7oHNynY0Hc=",
      "url": "assets/help/quickhelp-en.xml"
    },
    {
      "hash": "sha256-+H9kprsZY1ijx113jm2zeCy1mtv89QNyhSumN9tCops=",
      "url": "assets/help/quickhelp-ru.xml"
    },
    {
      "hash": "sha256-t1YB7amYWYafBzjgXdZVqp243XpIxS2zU0SQX4pNQ1U=",
      "url": "assets/images/distribs/distrib-01.svg"
    },
    {
      "hash": "sha256-a0rGNBW9r94xGlK2PJx6AAFSVWIBqgKyB8yt44/H35M=",
      "url": "assets/images/distribs/distrib-02.svg"
    },
    {
      "hash": "sha256-wipD6J8mNuzeThfRxzMv2/Dkgxlpk72GTc2sia/3/6Q=",
      "url": "assets/images/distribs/distrib-03.svg"
    },
    {
      "hash": "sha256-UjhCF0NSI/j7aO+O4J+jabORpGrVinQhL2P86b3HVxw=",
      "url": "assets/images/distribs/distrib-04.svg"
    },
    {
      "hash": "sha256-WNVVx2HlJvS7iTzo7EqsoeFRjE4iwieteaW7UBoi2Cc=",
      "url": "assets/images/distribs/images.json"
    },
    {
      "hash": "sha256-zrOl8Fp0m5S9yDbKh8lVKr314xSU5h67PWtN5QrZ2+g=",
      "url": "assets/images/etc/book-thumb-default.svg"
    },
    {
      "hash": "sha256-HNwLE4IO86G9WeaiEtLgJcYLTt7zreq8hhcu+VDIQq8=",
      "url": "assets/images/etc/distor-default.svg"
    },
    {
      "hash": "sha256-Qw7aWc02+mP+jn+Cqu/DoGJF6hLb0MySjyZR9qzYito=",
      "url": "assets/images/etc/library.svg"
    },
    {
      "hash": "sha256-XQ0OLCA9fBl0QFx4DUMYL5Yc5akZsrXEq1j+VkGKsjI=",
      "url": "assets/images/etc/shelf-realistic-one-level.svg"
    },
    {
      "hash": "sha256-hseWS5G8q3EBfWV3GxmBmlxadHD1zhbhB6j56nXN/ms=",
      "url": "assets/images/faces/face_01.png"
    },
    {
      "hash": "sha256-4bfizFTx+t7ECOr9ne2uCEEZIWIPWS4JpnRbDTcaSTo=",
      "url": "assets/images/faces/face_02.png"
    },
    {
      "hash": "sha256-nZWK97ecD0W+vLaqc5t8WktQiPB1NL6BA3/HYCl0+Fc=",
      "url": "assets/images/faces/face_03.png"
    },
    {
      "hash": "sha256-84oCqtI2OiFPAuNhd6lGVplRwICubl3OoWkumOvLli8=",
      "url": "assets/images/faces/face_04.png"
    },
    {
      "hash": "sha256-z0Mneda1b3WkRldBitEOVuu8enEbQtf2trfYcJDsY6Y=",
      "url": "assets/images/faces/face_05.png"
    },
    {
      "hash": "sha256-1bM8BfQEVSMg+3WPM/jMl7x5G1Jr9OJyKqOp/GnKIqw=",
      "url": "assets/images/faces/face_06.png"
    },
    {
      "hash": "sha256-3QmgPXwxBPctvb0M5FjuVC1pq4L+CfGN3fiP1l5MW+0=",
      "url": "assets/images/faces/face_07.png"
    },
    {
      "hash": "sha256-5AuL/cqS73Ygm7rgj42JwewoiG0bv7RFHm4kWEBFVfA=",
      "url": "assets/images/faces/face_08.png"
    },
    {
      "hash": "sha256-En7VUgbEWVy8kiYdG9GhfxJ06Wvg3gEAqD86QvDUczc=",
      "url": "assets/images/faces/face_09.png"
    },
    {
      "hash": "sha256-czLrOGYA7CVWKiLbDFADmbL6ct3VZ/bu1UjFDDz1Wjs=",
      "url": "assets/images/faces/face_10.png"
    },
    {
      "hash": "sha256-0zumCQEieiYCmSyub05e/uNFSJo4McaYqQNm+11hmHU=",
      "url": "assets/images/faces/face_11.png"
    },
    {
      "hash": "sha256-XUXnV8fFDPmlUCv6exu9+2jY4Raf4mOQhV0PPLSiYXc=",
      "url": "assets/images/faces/portrait-navy-01.png"
    },
    {
      "hash": "sha256-Fdx+vDfuh0iGfK6+9AGfSwT9boVdLjuWpPA2S/dgZ34=",
      "url": "assets/images/faces/portrait-navy-02.png"
    },
    {
      "hash": "sha256-qatM8fZzX8J/b3lMM8YT0i6YmRW5giItHMfbyL+mz4A=",
      "url": "assets/images/faces/portrait-navy-03.png"
    },
    {
      "hash": "sha256-fpIYkZtqHnZxZXL96md37monbTCj+jVnUMcEjfpM8r0=",
      "url": "assets/images/faces/portrait-navy-04.png"
    },
    {
      "hash": "sha256-X/mZSo5FG/woI9Y2j4Y3pw8IvDT+SGtXqiDfsns43Z8=",
      "url": "assets/images/faces/portrait-navy-05.png"
    },
    {
      "hash": "sha256-g91Lz8lHt2BfqN0Xan6S/HTtr1kKXFo/BIlpDIunnPk=",
      "url": "assets/images/faces/portrait-navy-06.png"
    },
    {
      "hash": "sha256-wAsB9HzU9mYufZ7nm1AcNX2MyyDrtXOryx+VuOGc3r4=",
      "url": "assets/images/faces/user.svg"
    },
    {
      "hash": "sha256-HUYDeoBMU4Yo6ZhO5VtDHGN2l7vN1tGDhqlBHmuMAAc=",
      "url": "assets/images/faces/userfaces.json"
    },
    {
      "hash": "sha256-5XYmcI8SsCdWOp3MldCwGbg5HrkVTLcMp8Zb1Oqa3OI=",
      "url": "assets/images/flags/ac.svg"
    },
    {
      "hash": "sha256-ugrr47IngdWvMBURdVKDdB0Xt7aapIW19ctQdpiifII=",
      "url": "assets/images/flags/ad.svg"
    },
    {
      "hash": "sha256-hYVqJMuKcRE3iKJaUYDTNBbJePH34IOJolcXOd8OYpw=",
      "url": "assets/images/flags/ae.svg"
    },
    {
      "hash": "sha256-aUK2aDWAEHUER4VJLX8B5spK2FIVzVP4cmqmjzfwBkc=",
      "url": "assets/images/flags/af.svg"
    },
    {
      "hash": "sha256-AgjkD1VOMnzguGpf6WbsozcRE2a/tR1+Ysnoqz0JJhU=",
      "url": "assets/images/flags/ag.svg"
    },
    {
      "hash": "sha256-SS0/r4/0VnIPApIEx9QZ+IMMDPxgCyWPOunvwQ/MfbI=",
      "url": "assets/images/flags/ai.svg"
    },
    {
      "hash": "sha256-MqTdupgoN9JP1stCbqAlK3naVYE+AHx/4MQ+L2QWD2o=",
      "url": "assets/images/flags/al.svg"
    },
    {
      "hash": "sha256-8BotceMq9VzAKzXAiZ2G+KBOPGW/NH26lRSMRm0U884=",
      "url": "assets/images/flags/am.svg"
    },
    {
      "hash": "sha256-P72Mk50KIy/GXC1GMfk9VMmXtH/Sw9BnJNpxYuctdmU=",
      "url": "assets/images/flags/ao.svg"
    },
    {
      "hash": "sha256-OjOLqXxawDgvUbErXF05teE7bMWT4+12TGEV/LKnNEA=",
      "url": "assets/images/flags/aq.svg"
    },
    {
      "hash": "sha256-pIEsX2iIoWfAvxvGVbedbrDimS4btnmdVNvx9FELwU0=",
      "url": "assets/images/flags/ar.svg"
    },
    {
      "hash": "sha256-ZXx7/jAMcYkHPQogYMdDD6ziyTaIoiHrc4ygrEb6Jds=",
      "url": "assets/images/flags/as.svg"
    },
    {
      "hash": "sha256-9o20XuQ3zm9Cdjlnp5NUk/rpqiUqnFLO3Xz+wxGx+Pw=",
      "url": "assets/images/flags/at.svg"
    },
    {
      "hash": "sha256-rmDGJXVkgR18grHa5pQ9OgKp5xzus63b5TmHoNPfvKQ=",
      "url": "assets/images/flags/au.svg"
    },
    {
      "hash": "sha256-+O5+v2Ru1w3MfXx3UYWn1RXZqZMlH3zp1L/1hdJgIh0=",
      "url": "assets/images/flags/aw.svg"
    },
    {
      "hash": "sha256-BLv9z0RyIhPvBEfkiy0LkIJNgfEWx6KYNQz6j00pb30=",
      "url": "assets/images/flags/ax.svg"
    },
    {
      "hash": "sha256-lEp48OwaurJL5qneYl3Py8UQ9wtePFzBod8I/EnbJ9s=",
      "url": "assets/images/flags/az.svg"
    },
    {
      "hash": "sha256-uC/ECRlGzwM6vqxZUVtM1SF/XB7jijV4Sbkq+6oC9xM=",
      "url": "assets/images/flags/ba.svg"
    },
    {
      "hash": "sha256-F0o3gh0gx3NVdxJx0InSSmIFuSO5RkgmNC17J4foJ50=",
      "url": "assets/images/flags/bb.svg"
    },
    {
      "hash": "sha256-V//Ow4o7MG6ACGdLti4kfKuFW/nZ5Se5pQRpHSpqaI4=",
      "url": "assets/images/flags/bd.svg"
    },
    {
      "hash": "sha256-6jcgNRZ+5Nx3JTw1g2nZW4lTnyllzz3KcpPuayj1OgE=",
      "url": "assets/images/flags/be.svg"
    },
    {
      "hash": "sha256-aZFj5vHJb7O11C1nJS2jUBUv+kxZjzR2L+reZu3hWWg=",
      "url": "assets/images/flags/bf.svg"
    },
    {
      "hash": "sha256-0WG1piNlCi62NLzLBJDp/T7iDS/0ttMd+KM1/nEBtus=",
      "url": "assets/images/flags/bg.svg"
    },
    {
      "hash": "sha256-HLdyVpkL5JhVkED4Zp5FLolvPtmVV3FfBM/o9V+iTLA=",
      "url": "assets/images/flags/bh.svg"
    },
    {
      "hash": "sha256-oehiTzZBo6v3lCN10mGlXMpsm/v6DrpNLSnCTi2Yaag=",
      "url": "assets/images/flags/bi.svg"
    },
    {
      "hash": "sha256-3jQgIDHvJ0fvDGl1zYGF21q4DMZ54ZMv8kiZSoRZEfo=",
      "url": "assets/images/flags/bj.svg"
    },
    {
      "hash": "sha256-Vlc8bd7RhAurbpjv2cIMyeyOKRYtz/o3nZUnfaYab3E=",
      "url": "assets/images/flags/bl.svg"
    },
    {
      "hash": "sha256-kSlGXaNMgxXAmLOCyruDQ/Wx7znULT8vbt1xYjliDuw=",
      "url": "assets/images/flags/bm.svg"
    },
    {
      "hash": "sha256-czVlmhhRQ0Z6VKhDP5KURtZ3t03w7dQ2N8MUVHASNB0=",
      "url": "assets/images/flags/bn.svg"
    },
    {
      "hash": "sha256-YrmbX8tR0Enahr/Kch4JXZO6Bb7CBepvniIfRRU3ldk=",
      "url": "assets/images/flags/bo.svg"
    },
    {
      "hash": "sha256-82zy4KPfX/3oaKoLa7qjzD7Fl10eS5R14UYpnxnpCJw=",
      "url": "assets/images/flags/bq.svg"
    },
    {
      "hash": "sha256-Lr9t0ftsh7vXew/AI8fDq8v6t30fl8Kbj8H+Cgo5jaQ=",
      "url": "assets/images/flags/br.svg"
    },
    {
      "hash": "sha256-auYvbuYZXcw/isP43Q1J5R3fJnXya+ycn1316pqrBAY=",
      "url": "assets/images/flags/bs.svg"
    },
    {
      "hash": "sha256-7rRbdnLPIeN0MTFM0GLvi6Vn2Svtj0LJfyU9kkbr9DM=",
      "url": "assets/images/flags/bt.svg"
    },
    {
      "hash": "sha256-OtM85LC4aB+Wa1HV0RYzU5XYfFRxN90ltne1trJVXrc=",
      "url": "assets/images/flags/bv.svg"
    },
    {
      "hash": "sha256-l/unBJ0kmAJ6bUV1/+kzVhe9JmomBr74WsMlTiq63+E=",
      "url": "assets/images/flags/bw.svg"
    },
    {
      "hash": "sha256-/Qq15fP1obV9K4HaHkValUPEeZBANFEtjcJZLi7BoVI=",
      "url": "assets/images/flags/by.svg"
    },
    {
      "hash": "sha256-BTMg6YPZwkjQ3iICPkpbyTtbn1eXAz6SweqnB+2vfaY=",
      "url": "assets/images/flags/bz.svg"
    },
    {
      "hash": "sha256-BBQPIHajkx+QCBgLww3jNM5HuVL47BM3Fg+kPbohAEo=",
      "url": "assets/images/flags/ca.svg"
    },
    {
      "hash": "sha256-AwBkl/7Ni00RK2pNzDA4xFUhQKO0XaGhdEUMLFweAEU=",
      "url": "assets/images/flags/cc.svg"
    },
    {
      "hash": "sha256-TWBjc8Qr72S8+qkAJn3/Qw7GSqjzLcIu7t7AVhNB5+A=",
      "url": "assets/images/flags/cd.svg"
    },
    {
      "hash": "sha256-0O1PW9XFVr5HgohQoXkTXYYweKccGRInJvzCTGNK0qQ=",
      "url": "assets/images/flags/cf.svg"
    },
    {
      "hash": "sha256-9N/vbId7aChAx4O4/oBghHANCdiCQ47hsGPy2mYkUgA=",
      "url": "assets/images/flags/cg.svg"
    },
    {
      "hash": "sha256-7/uuJ2wcztr+kZgBnFfdeYXnBXaGmKyyfWmC29h5dVA=",
      "url": "assets/images/flags/ch.svg"
    },
    {
      "hash": "sha256-rZOjsZDeaosFQ+H6fb/2uJ8iDT0t4/oWYiocJ8ScUO0=",
      "url": "assets/images/flags/ci.svg"
    },
    {
      "hash": "sha256-jg4zePAJmViqfeqMjgt+1HNcjHo+p9SwzW/EjHUrQNw=",
      "url": "assets/images/flags/ck.svg"
    },
    {
      "hash": "sha256-PfX5tYSL0DYH63cfnl16e5XReT4LTM+OmGMk6le/GCA=",
      "url": "assets/images/flags/cl.svg"
    },
    {
      "hash": "sha256-ajb27sEAyIxxYqen1QbY/h8CL2LvPt6U+GP44WgIw+4=",
      "url": "assets/images/flags/cm.svg"
    },
    {
      "hash": "sha256-UFZ1Kkau43QkfEzPSfEirwQefHydEPb6hDy2bujb4fY=",
      "url": "assets/images/flags/cn.svg"
    },
    {
      "hash": "sha256-C3OvZ8p40qDySnSAecwYxuGgTIsFBsJdlq/w5o3xV9I=",
      "url": "assets/images/flags/co.svg"
    },
    {
      "hash": "sha256-q8nFewjQWlIbf0LoEjJqFH3BynaIQJtKmqZxH7Zm8S0=",
      "url": "assets/images/flags/cp.svg"
    },
    {
      "hash": "sha256-LoR/zOonp9uru4JpSAm6fuZZwZeI2yxignHcadhvd+w=",
      "url": "assets/images/flags/cr.svg"
    },
    {
      "hash": "sha256-AAjE1OKZz3aqE9fYGx5wCVPSiQZwW0RF3/zN11PCQog=",
      "url": "assets/images/flags/cu.svg"
    },
    {
      "hash": "sha256-fGGQuPZ08iH9RGmTRRFsWksH3GkDsd07zAhVsvh2+6Y=",
      "url": "assets/images/flags/cv.svg"
    },
    {
      "hash": "sha256-x+H4aM12x+PB1oKbMdSKNKAoAmu/7AMgoYmYGygiRcU=",
      "url": "assets/images/flags/cw.svg"
    },
    {
      "hash": "sha256-q7YzDfCsS4+3ioTJipPzvyXCzA3jvT5IuXycgLCsdKo=",
      "url": "assets/images/flags/cx.svg"
    },
    {
      "hash": "sha256-UW0+CR4Ey2VtmmfybYWN+K8xgN/fR8SM49bA201Q7hk=",
      "url": "assets/images/flags/cy.svg"
    },
    {
      "hash": "sha256-X5T5Ws8u+fkKBVlNHpY3PZ3YTINCFO15pkrHL/XEgEY=",
      "url": "assets/images/flags/cz.svg"
    },
    {
      "hash": "sha256-6g3YtZX/l4jY9VnGCa18tfqKAwUz0ZRsz8RsXgvnSbM=",
      "url": "assets/images/flags/de.svg"
    },
    {
      "hash": "sha256-7ErdUkhHbN+Cc/IK4z4I7w3VTlwhVDRaLejNcpM4m6E=",
      "url": "assets/images/flags/dg.svg"
    },
    {
      "hash": "sha256-SnwZZzLF1Zg5YZdSUBmr+fRlK5v8oJO4kBAKriy4DZc=",
      "url": "assets/images/flags/dj.svg"
    },
    {
      "hash": "sha256-7fQkorZefREItm902a3mrSQNvcftArNVw89kUMa0pQY=",
      "url": "assets/images/flags/dk.svg"
    },
    {
      "hash": "sha256-eOE9M9hbT8LwMRU4773opPcMMLFeKEXkTRlAe/a7+o0=",
      "url": "assets/images/flags/dm.svg"
    },
    {
      "hash": "sha256-xiejCUN6i1TgpEG2cS2HCiNMmSdVmqC/XH4rAf3G/y0=",
      "url": "assets/images/flags/do.svg"
    },
    {
      "hash": "sha256-j2mLXA+h4MEOiMjQMYrqJYgFcBfqb1TVQURbRqdLhKg=",
      "url": "assets/images/flags/dz.svg"
    },
    {
      "hash": "sha256-hwmQevLxV622+WECH0yLVoi2ln3znOpFUAGjZnqVjcI=",
      "url": "assets/images/flags/ea.svg"
    },
    {
      "hash": "sha256-ayBCK8KFZEfYF/Os52aldjuZkNLIBA2EOuCzuRGQx68=",
      "url": "assets/images/flags/ec.svg"
    },
    {
      "hash": "sha256-nPNTCl1yZD51nu1Yw1y+FC0SGKqqJR8m8Eme9lDO2kU=",
      "url": "assets/images/flags/ee.svg"
    },
    {
      "hash": "sha256-zpgYWO7ZvCvNUMY02yTzVi/I8SQxKKNpCJMv7c/zZAA=",
      "url": "assets/images/flags/eg.svg"
    },
    {
      "hash": "sha256-ewJTleyaqMhX35LiLBcMHuBquNNzrIzk5f7ihYBd5vQ=",
      "url": "assets/images/flags/eh.svg"
    },
    {
      "hash": "sha256-n+2Tbu2+veuuTkO3rKJyffvu6sznrha2L4XWvb+4sgs=",
      "url": "assets/images/flags/er.svg"
    },
    {
      "hash": "sha256-K4tjY+ccCYElTcSbu21dZXAN9ccJkTYkXh1Y88ScXt0=",
      "url": "assets/images/flags/es-ct.svg"
    },
    {
      "hash": "sha256-xUxmS72LSqsCfu/tuhyb/fvX+Shrj1fTNHCoFjIe4yo=",
      "url": "assets/images/flags/es-ga.svg"
    },
    {
      "hash": "sha256-mRQgBC2lHbJ448fcA0sFZvuf2I0b3PfxnHkYH6eqxYs=",
      "url": "assets/images/flags/es.svg"
    },
    {
      "hash": "sha256-4UkQveBXO1cDZwnTHXuskk7XUEcq6Z00nGntwvgJhVQ=",
      "url": "assets/images/flags/et.svg"
    },
    {
      "hash": "sha256-YQldtr+DQopo2ECnH8BUOU39o8nvns2C2SJg1YNtZmo=",
      "url": "assets/images/flags/eu.svg"
    },
    {
      "hash": "sha256-fdAT8H+e++fz6vMX3t1C0f/6lXHkezFG43c1i9jBzR8=",
      "url": "assets/images/flags/fi.svg"
    },
    {
      "hash": "sha256-A2EOcAqB89c0otLaCyqHbgD9QlltVH8NdPRvQoMquTs=",
      "url": "assets/images/flags/fj.svg"
    },
    {
      "hash": "sha256-swInvF8JEP1EhErQ++JPIHt3mRRLri3WUtmHCHS2+Gg=",
      "url": "assets/images/flags/fk.svg"
    },
    {
      "hash": "sha256-rXqBk8gOLBccboxSt4dpiaDXpidqpwdtLYkrOJvVtTo=",
      "url": "assets/images/flags/fm.svg"
    },
    {
      "hash": "sha256-WwvvQWaFY+LyzgOPFOg8swhJokStjwxi+IErOyqSzNM=",
      "url": "assets/images/flags/fo.svg"
    },
    {
      "hash": "sha256-aic97/D5OPUSdIXDtVLOGM7JzehMktXkEX2mV0oQ798=",
      "url": "assets/images/flags/fr.svg"
    },
    {
      "hash": "sha256-rUD/jt6xIFDR/JIIMtXxo+etiP2ospbkF6Ut+GhqQzI=",
      "url": "assets/images/flags/ga.svg"
    },
    {
      "hash": "sha256-STx+C1liQTpIGJfQfsN1uZQJW1306ceJpWvyVQ44Mn8=",
      "url": "assets/images/flags/gb-eng.svg"
    },
    {
      "hash": "sha256-NjLyR+CvlkEFyAHivuttfP7JDXmd5ynKnRnlsUOGXLQ=",
      "url": "assets/images/flags/gb-nir.svg"
    },
    {
      "hash": "sha256-BNZFbbyyZwfuBF4Nt/lbDykNbeZVZ1fVaIO9+CljhCM=",
      "url": "assets/images/flags/gb-sct.svg"
    },
    {
      "hash": "sha256-CwUZRqXTKnlI1ma8FWCnOM5K4LZInf8hURG54YDZsls=",
      "url": "assets/images/flags/gb-wls.svg"
    },
    {
      "hash": "sha256-OR02PeC9zazhOsr0b3BQAbP4nT3t5P8YqMt/wgL+yEQ=",
      "url": "assets/images/flags/gb.svg"
    },
    {
      "hash": "sha256-TIIMhLGbPnTLox3uYaJjvSKT0DCo0IaGjDQRpvA0xXY=",
      "url": "assets/images/flags/gd.svg"
    },
    {
      "hash": "sha256-mvCTR1tDDFNTSG2UdxMGUoCwEf3781PQjuji5tCIDJY=",
      "url": "assets/images/flags/ge.svg"
    },
    {
      "hash": "sha256-OBtWwK96AsnOe4yrNKEeuNm+Qi4DJJ3Js+UGY0EwmSM=",
      "url": "assets/images/flags/gf.svg"
    },
    {
      "hash": "sha256-1s2Cpb6IXkOXcRLzsGazeVrU6Lf68ldupVmQM5/sNS8=",
      "url": "assets/images/flags/gg.svg"
    },
    {
      "hash": "sha256-Sbrujid4dxk/3hpiDH5DWvXwn8ZI424OqL7l4XCR48U=",
      "url": "assets/images/flags/gh.svg"
    },
    {
      "hash": "sha256-mpdpABlYDuwxk9MtkyybKBcprd+dWowKzzDXJyw36WU=",
      "url": "assets/images/flags/gi.svg"
    },
    {
      "hash": "sha256-Jkq6BRwDUJ5fAWlRejIdzWa8+kF58vo8O09fG3sOtmI=",
      "url": "assets/images/flags/gl.svg"
    },
    {
      "hash": "sha256-3r5iyXSVfcikuVsjxnTs7Pnkdvu5WgHRpYmfbeAK6TY=",
      "url": "assets/images/flags/gm.svg"
    },
    {
      "hash": "sha256-fogvu5FWXkKZyf+dTHSoxuPayb1PJiL953WG6bAkIaA=",
      "url": "assets/images/flags/gn.svg"
    },
    {
      "hash": "sha256-z3G+0I/qDjjr2aKTFeppBtiOwedgtl8IWzvZf+rp0Js=",
      "url": "assets/images/flags/gp.svg"
    },
    {
      "hash": "sha256-W+N4fAdODdx+82tQfrzPu1hTKvctueV++stuC2JPk9c=",
      "url": "assets/images/flags/gq.svg"
    },
    {
      "hash": "sha256-F65XjMQOugUYEoDSmVH0Ycq4IT0Vt3tgyabhb6bxm3M=",
      "url": "assets/images/flags/gr.svg"
    },
    {
      "hash": "sha256-NBwZNjVRAJYe5B6soIlRGUZyj9Xp+vh8CsktcB5RwQA=",
      "url": "assets/images/flags/gs.svg"
    },
    {
      "hash": "sha256-4I5tuQwuDRG3AsPmb14zv7Q682xdmELfviSkSK8I4L8=",
      "url": "assets/images/flags/gt.svg"
    },
    {
      "hash": "sha256-br62Pt1LVHcJ2wNTcQsobOah2FpyyGQFmvJCtN0Jj5w=",
      "url": "assets/images/flags/gu.svg"
    },
    {
      "hash": "sha256-FO8qvLZHBSJxds9wVWnzsKM4U9cC6DPURVMvgKlS5GQ=",
      "url": "assets/images/flags/gw.svg"
    },
    {
      "hash": "sha256-6/ayrvN7NiAvpTjnyWy4PCiXu+euAX9Q9JAwjJk4zE4=",
      "url": "assets/images/flags/gy.svg"
    },
    {
      "hash": "sha256-8toOTbJj4VZHTqgR0oj2MC/2ZW0adQPOyWFX9k0Xrko=",
      "url": "assets/images/flags/hk.svg"
    },
    {
      "hash": "sha256-QaPHivNWsP4eIGikfjEazgJyGNgeK84kjK6p7qd7xes=",
      "url": "assets/images/flags/hm.svg"
    },
    {
      "hash": "sha256-fKUnAF5lk9+4fEEJinOCCzpzG3fX/J9xR6jx1owYV+8=",
      "url": "assets/images/flags/hn.svg"
    },
    {
      "hash": "sha256-hsHBGWzvyaIG4BakFIZs3AF5GO+4R10JI95FHEon26w=",
      "url": "assets/images/flags/hr.svg"
    },
    {
      "hash": "sha256-8TWWtgmzWXqen5yfpbIeCdDs/UJxTi/8uX9xljwP0HY=",
      "url": "assets/images/flags/ht.svg"
    },
    {
      "hash": "sha256-hbKheYa7ax30iTfN6T4aLQFnAAKebefrm0Ov5m672jY=",
      "url": "assets/images/flags/hu.svg"
    },
    {
      "hash": "sha256-6VT56Qx7BTvSw3QXFAKtZdAViIc8NOOhUzgiiesCwEo=",
      "url": "assets/images/flags/ic.svg"
    },
    {
      "hash": "sha256-HJ+PZ4afCPu1zmjL5veFGvEjoEbjgn/JBHu9S+Gcdww=",
      "url": "assets/images/flags/id.svg"
    },
    {
      "hash": "sha256-0ryJDfez06pepqdZFvdXY9gpA18fbQECUu0yaYw9pNg=",
      "url": "assets/images/flags/ie.svg"
    },
    {
      "hash": "sha256-ukUHg9pIQ0HtKAEmA8qOHKGCEkInnZj9t9BumNWPBf4=",
      "url": "assets/images/flags/il.svg"
    },
    {
      "hash": "sha256-d5p3LkffvaeJ/XEDyZ9pbRAlFDkSQ2RdYmDUP34Xze4=",
      "url": "assets/images/flags/im.svg"
    },
    {
      "hash": "sha256-+EkJ6P15dh7xnmuH5IAaxPh5v5gnJF7I87LLgBAbW1g=",
      "url": "assets/images/flags/in.svg"
    },
    {
      "hash": "sha256-7ErdUkhHbN+Cc/IK4z4I7w3VTlwhVDRaLejNcpM4m6E=",
      "url": "assets/images/flags/io.svg"
    },
    {
      "hash": "sha256-IMgQHmt0FFUQNM3keitaGZxzw0XmtN0Q1cTOphfWEtc=",
      "url": "assets/images/flags/iq.svg"
    },
    {
      "hash": "sha256-NmnEOvZ0AcqGEYAj+oMJrSHrzHKXax3axDtnSaP32l4=",
      "url": "assets/images/flags/ir.svg"
    },
    {
      "hash": "sha256-yKrcWmpnLIGAdFwTC9wMRG7Yf93pAM3kWrjPVUUMS6Y=",
      "url": "assets/images/flags/is.svg"
    },
    {
      "hash": "sha256-8kKjgDath8n7x9sbkBu8Jz2gwQgS94NIWGK84/pUepc=",
      "url": "assets/images/flags/it.svg"
    },
    {
      "hash": "sha256-6828HDVhCKS4t337SrRKWl2jW38cI/+nf5omgtQVj3E=",
      "url": "assets/images/flags/je.svg"
    },
    {
      "hash": "sha256-1pRTDoL6UXrtzVB5941d2cw2ZtX76A0fgrK26vG5GA8=",
      "url": "assets/images/flags/jm.svg"
    },
    {
      "hash": "sha256-tvN5SOcWMI68tinJMuj4HJ3WNajiAujSl9PHzMpdLg4=",
      "url": "assets/images/flags/jo.svg"
    },
    {
      "hash": "sha256-KvzwLaDpsWpFpHIqNtzVDyHLX9isLaZ7xUwbHt8X7Dc=",
      "url": "assets/images/flags/jp.svg"
    },
    {
      "hash": "sha256-pJMQZ5eYNWikMHWwiuZ4JT3wbAkaxK2H3keF66ev3yI=",
      "url": "assets/images/flags/ke.svg"
    },
    {
      "hash": "sha256-ocDfFf+sHL3WVBPA4jv/UiSuQjxJA1jCODbQH1f0Q2I=",
      "url": "assets/images/flags/kg.svg"
    },
    {
      "hash": "sha256-htZ+KDAkz+2V/ekxibJlIlK0ssdczBHs6/gPLaiSsaQ=",
      "url": "assets/images/flags/kh.svg"
    },
    {
      "hash": "sha256-4/yz8d7UhoYDdd0Z1pOxdPaRMEmNtXsWonnigsRbSOs=",
      "url": "assets/images/flags/ki.svg"
    },
    {
      "hash": "sha256-OA4GeMzwhDSgpK+jBnyjeuKCb+l/p0BQ869O9rDg7q0=",
      "url": "assets/images/flags/km.svg"
    },
    {
      "hash": "sha256-5r3FYEP5rzzkEGiTqTDW6BIYEhE7DYzWjG0OjuaB3FQ=",
      "url": "assets/images/flags/kn.svg"
    },
    {
      "hash": "sha256-lJu/HZWWcvhWQZw7fmUHD98w01J3hrJxtMUiuvbci38=",
      "url": "assets/images/flags/kp.svg"
    },
    {
      "hash": "sha256-wTTrURBJinx0PcVJYh0VfKkItcrfhwFO6b/hqPVOgEo=",
      "url": "assets/images/flags/kr.svg"
    },
    {
      "hash": "sha256-3O5OqpIX0WE/6xh5aruHoA8ackISJn0XKd1s/CWeau8=",
      "url": "assets/images/flags/kw.svg"
    },
    {
      "hash": "sha256-3uWfqPAV1VtbEXXLo3ttye+W2UOHadt91rRC17j7SUc=",
      "url": "assets/images/flags/ky.svg"
    },
    {
      "hash": "sha256-b/NZs3jBvN1T0GxyPApEzEEFrtx4kiV7czg2P2jv4JU=",
      "url": "assets/images/flags/kz.svg"
    },
    {
      "hash": "sha256-LKNIanGnn2xrfCUMcB632I5BaUa/ZOnwx0ruIk/HikQ=",
      "url": "assets/images/flags/la.svg"
    },
    {
      "hash": "sha256-5PjpepuBgOOqST0q1CV0KLGQpl3218e6CaH9/FwcjQk=",
      "url": "assets/images/flags/lb.svg"
    },
    {
      "hash": "sha256-4EGzES+N+TWSX8+UXGFptUhWZW2hspKlIttK4ZG7zto=",
      "url": "assets/images/flags/lc.svg"
    },
    {
      "hash": "sha256-wu2mNjG1JIMIZkGvwK6mf1XTYmq5qUAMSZY+l50DbdM=",
      "url": "assets/images/flags/li.svg"
    },
    {
      "hash": "sha256-N8n2qGvw5O7+N9hzdk/4q83TDsvHBHnLg1nce3KGgn0=",
      "url": "assets/images/flags/lk.svg"
    },
    {
      "hash": "sha256-O5ueUZIpMv3UGtgkf7PpAnh0S8/tpPTt1ZG0/oBDUcU=",
      "url": "assets/images/flags/lr.svg"
    },
    {
      "hash": "sha256-ttEK6pOTAfol/LlEnRpGvc3rglDhl+a9N2mvGy3TCVM=",
      "url": "assets/images/flags/ls.svg"
    },
    {
      "hash": "sha256-lCaJOgBKWGEGHsRZEI02PwAy5IYb85hzIUJ2NZ0vZ6o=",
      "url": "assets/images/flags/lt.svg"
    },
    {
      "hash": "sha256-go3xin/Pe+vSg1UnTZUVzxaLPF0ik2/+rb0u0s4Uu58=",
      "url": "assets/images/flags/lu.svg"
    },
    {
      "hash": "sha256-8d4OcFtGEW/b5QMBiYQINsdt+lt7SPgBDV7StVe9RiU=",
      "url": "assets/images/flags/lv.svg"
    },
    {
      "hash": "sha256-r1rI9buOrmXL90a24pGHyny02MxxxBlWKd4QBdI5QK4=",
      "url": "assets/images/flags/ly.svg"
    },
    {
      "hash": "sha256-FNwoljTKneqU/5fMPgexhzyCAPrVY2OYBFnIZgMvGD4=",
      "url": "assets/images/flags/ma.svg"
    },
    {
      "hash": "sha256-IMWBoPcp8d7qo1b+9J6UXxuDf6INhLr0Gop+o/pC+g4=",
      "url": "assets/images/flags/mc.svg"
    },
    {
      "hash": "sha256-Kx3FjxVEhpWJ7sSETLkRDG+J9SjvzYAYaPqt2kKItdQ=",
      "url": "assets/images/flags/md.svg"
    },
    {
      "hash": "sha256-Ivj+S5dQbFQchK7tBkC/T0NTQwfoOqOpU+l0MOCX2zc=",
      "url": "assets/images/flags/me.svg"
    },
    {
      "hash": "sha256-J4oS/YeSVqDaWES8OW9VjtYqVJu41BN61R0yc+pNvZs=",
      "url": "assets/images/flags/mf.svg"
    },
    {
      "hash": "sha256-Ba6pytYTQYpQHU8Tp5tTJsRkexfToD7bGQaZ3ph4sEo=",
      "url": "assets/images/flags/mg.svg"
    },
    {
      "hash": "sha256-Kvg5IeAoqmR3+ShsuCaTaZR3sYS5mRwVklze5/30O74=",
      "url": "assets/images/flags/mh.svg"
    },
    {
      "hash": "sha256-EDpxzsCI8C6iJuEciFCmQwyELywruRItOI/WUVLgQ8I=",
      "url": "assets/images/flags/mk.svg"
    },
    {
      "hash": "sha256-9X7ogFAvbMI2uOodn4mp+TOyS9Uwt4S4wQlo43FPPKk=",
      "url": "assets/images/flags/ml.svg"
    },
    {
      "hash": "sha256-cV1h1WrKPsTR9VEYW4BwAi7ftsbB2eMon5WxN6nv+e0=",
      "url": "assets/images/flags/mm.svg"
    },
    {
      "hash": "sha256-M1oKAwaHwCOnSMXFAYMjMb+efskmYXhQDFbtTNnqAkk=",
      "url": "assets/images/flags/mn.svg"
    },
    {
      "hash": "sha256-vyOfUmu+yGAuJaKlZcClbfiwx5M7v6uS7skd9j0vhtU=",
      "url": "assets/images/flags/mo.svg"
    },
    {
      "hash": "sha256-9P4hUP3t6kOERAJF/uA35bF8rYaP+arXweNiVYkMccI=",
      "url": "assets/images/flags/mp.svg"
    },
    {
      "hash": "sha256-KmrMfoSeBlLTg2SQUHUctIbgIdN8iH8BOnJX9ms7xLQ=",
      "url": "assets/images/flags/mq.svg"
    },
    {
      "hash": "sha256-d/KQ/ZID1z21eDXfTSN0Wq8IsvrhXS85hUBA4z6xgRs=",
      "url": "assets/images/flags/mr.svg"
    },
    {
      "hash": "sha256-2dsIzvMqaiEf9d8hDbHBn33dxVUwLq2ECkcy5SPxFQE=",
      "url": "assets/images/flags/ms.svg"
    },
    {
      "hash": "sha256-ax2LebxER32n5AFwNGZo/qZ2aZaz/3YHvG4e8kKQA6M=",
      "url": "assets/images/flags/mt.svg"
    },
    {
      "hash": "sha256-bTNYBUQq0rHfWYCvhXdAM0u1dBrTDiRxkLP+plwYsOk=",
      "url": "assets/images/flags/mu.svg"
    },
    {
      "hash": "sha256-evou14AK+lkHfyzUo7bbPKRmSez+xAIMkL98SrUiz78=",
      "url": "assets/images/flags/mv.svg"
    },
    {
      "hash": "sha256-wXRWXRnCt0ceelq3Ra60DPUXe7eNA2AQxKskEYOnF1c=",
      "url": "assets/images/flags/mw.svg"
    },
    {
      "hash": "sha256-1//XPOpPUt4z3CDxIgbi61koR6fhWYjd6cuIMRQj3hU=",
      "url": "assets/images/flags/mx.svg"
    },
    {
      "hash": "sha256-NyduX7XNagKZ1NgBFW7ZGO5cF9Qa1wasVu25GNQX5oI=",
      "url": "assets/images/flags/my.svg"
    },
    {
      "hash": "sha256-NoJ5Dz5GYuj7dd3W51UdworosVFi0TdFr19pHy5Dmvw=",
      "url": "assets/images/flags/mz.svg"
    },
    {
      "hash": "sha256-09UYFa8Hgw4gHdoHpqKeYvM97OMPrKMZAXPemsOrulI=",
      "url": "assets/images/flags/na.svg"
    },
    {
      "hash": "sha256-Xc+0E7UB0stxc5bsykz/yEuwGVm5AZf8Y1112h7XeAU=",
      "url": "assets/images/flags/nc.svg"
    },
    {
      "hash": "sha256-21Y7SmF/bSwTTq8hVCZLcD9X6xhIDVutCPf6fQTF7Gw=",
      "url": "assets/images/flags/ne.svg"
    },
    {
      "hash": "sha256-dWYqwMogQDpIGP+IbqPjaWe5nAWnK7zWR/hDznsaitw=",
      "url": "assets/images/flags/nf.svg"
    },
    {
      "hash": "sha256-tq3JlCNSXy8tRyT/cgeKNU+rZ2VYQTDpH5FJBneOgJc=",
      "url": "assets/images/flags/ng.svg"
    },
    {
      "hash": "sha256-3Qfs9UY7AfkaBBNYdOzBfxQ2VuoYxt/vwDR9Jkxy02g=",
      "url": "assets/images/flags/ni.svg"
    },
    {
      "hash": "sha256-mKtHzG+Cp9K/tnLDo69eeNB1PtZbJStuWSZoT4L4dzQ=",
      "url": "assets/images/flags/nl.svg"
    },
    {
      "hash": "sha256-hCUSpQo35MNdIlcZZ4+/rjGCjMWCJbmn5B4jmP7CBEc=",
      "url": "assets/images/flags/no.svg"
    },
    {
      "hash": "sha256-wDQgMgzkVzB1dTH2WKd7h4CyI8jKtUasfdxNZDllZ+8=",
      "url": "assets/images/flags/np.svg"
    },
    {
      "hash": "sha256-rasQG7vkbdbIvcBSgWs7jazEKDcd9OIpmPT1Yj78lwk=",
      "url": "assets/images/flags/nr.svg"
    },
    {
      "hash": "sha256-xMZLJmiV9FETU51AbaiF9v05g0uEPpMNvaHd34Ne2tM=",
      "url": "assets/images/flags/nu.svg"
    },
    {
      "hash": "sha256-/+sboVx4iQwj6A4XVKidWo/PHO3Kc4wyHCTMFwaQFHs=",
      "url": "assets/images/flags/nz.svg"
    },
    {
      "hash": "sha256-EUr9xtX/rBPRAcimBzLBXXDB0GzSRzfaOVgPQMA+dMg=",
      "url": "assets/images/flags/om.svg"
    },
    {
      "hash": "sha256-CzGf/EpRFHtjTpbMw7sUNoaUYvtq8jx2icfOe8QgPgw=",
      "url": "assets/images/flags/pa.svg"
    },
    {
      "hash": "sha256-0eRsnFXP2PZrNHkNB2WNDLnqJyG/4ucILNxBB6dy3qY=",
      "url": "assets/images/flags/pe.svg"
    },
    {
      "hash": "sha256-FzC/1GVNVRskKrWJNbNoakUrVU1MIQOdD/98IGPo8Yg=",
      "url": "assets/images/flags/pf.svg"
    },
    {
      "hash": "sha256-ewoSWhzU/Zy6En8sQpHuraU9P+VDISVQmEWXQlp8aDE=",
      "url": "assets/images/flags/pg.svg"
    },
    {
      "hash": "sha256-AwhqlVMt0hv11iMdfF7M4cSNV3U0WxLKu9djLqKrD5A=",
      "url": "assets/images/flags/ph.svg"
    },
    {
      "hash": "sha256-+sSYGYl+pwpfkymoJDlqEznbeHhNVgZN/y4HHbrjVaE=",
      "url": "assets/images/flags/pk.svg"
    },
    {
      "hash": "sha256-M9bddYR4iKY07LKYffSKKHRziXVmKMMyQss1NHrqegY=",
      "url": "assets/images/flags/pl.svg"
    },
    {
      "hash": "sha256-d7oXiOL2HQHMZjJaTlM/SnW8Q7x+jce3E2LclzU/UDM=",
      "url": "assets/images/flags/pm.svg"
    },
    {
      "hash": "sha256-8F0JK6CRO+3jereSd4riwXRSEi3nhJnpi2ClmrmwTdM=",
      "url": "assets/images/flags/pn.svg"
    },
    {
      "hash": "sha256-Uk+a23tFLlFvX/NKuwYbGgTFXdct2tCXyV+ZEgmvPUY=",
      "url": "assets/images/flags/pr.svg"
    },
    {
      "hash": "sha256-7p/H6QVww9oo9Y+Y6g4lLwKs5NwOrzY0HESfMR9zPjE=",
      "url": "assets/images/flags/ps.svg"
    },
    {
      "hash": "sha256-+yzMsJCzMs9TtWjUsa1R+eq5xiBtaDECiw6EOmImX48=",
      "url": "assets/images/flags/pt.svg"
    },
    {
      "hash": "sha256-KTNxdt4eT+c+vXPiItC96QPdjhIMAm0C6QMP8CQ4Qdo=",
      "url": "assets/images/flags/pw.svg"
    },
    {
      "hash": "sha256-iBLtqDBQykvNmsmi1JNrEgrF9k7sHK0ojrgVbi9SC3g=",
      "url": "assets/images/flags/py.svg"
    },
    {
      "hash": "sha256-5PUpM//fh7kaU2vJw6Yq2CnzzND4WmZPbXrx4U94/rw=",
      "url": "assets/images/flags/qa.svg"
    },
    {
      "hash": "sha256-eJ9o84X49EczG0AhM31kGkU+t/10h4nBQRPvcAae380=",
      "url": "assets/images/flags/re.svg"
    },
    {
      "hash": "sha256-0AZ6qLmb84eOJrnXliukTL37Qgo0hXeGzyaB5iXvXiw=",
      "url": "assets/images/flags/ro.svg"
    },
    {
      "hash": "sha256-oHTTQNzt/V8a+YHZbQmCJ/AbiiCtfzAoLlR5xpMbGZs=",
      "url": "assets/images/flags/rs.svg"
    },
    {
      "hash": "sha256-UVE1NsY9e74NM0WUqYZJq8wGfYXaYE9tFfL+1dgyCKY=",
      "url": "assets/images/flags/ru.svg"
    },
    {
      "hash": "sha256-u31smamoiHe7u20uA8Qbcy8X7IBA8OdOO5aCSUwJ2j8=",
      "url": "assets/images/flags/rw.svg"
    },
    {
      "hash": "sha256-2Z5TsOQVX9/7oUqfLIP9MczS9Ko4djZWaH+xwfLiXQk=",
      "url": "assets/images/flags/sa.svg"
    },
    {
      "hash": "sha256-MMd0FT6IKMtpaLK4eW0D05ZVlwBodyVmifLve2DQcdw=",
      "url": "assets/images/flags/sb.svg"
    },
    {
      "hash": "sha256-RI1KdB99s2EoIu7Rk7AAqc3eewGhpf2X7AN/gDWtVIs=",
      "url": "assets/images/flags/sc.svg"
    },
    {
      "hash": "sha256-hkMP70tJ5cSqjCLLoez4O3amhjAsMXNoXPYp6mavllA=",
      "url": "assets/images/flags/sd.svg"
    },
    {
      "hash": "sha256-9m1oM8Ug6/H/e3GRFd4JUQZQp5hO0a7lpA0ve9862ZQ=",
      "url": "assets/images/flags/se.svg"
    },
    {
      "hash": "sha256-ZsTm+ybbQvyV47G+1Zxx0yVu5zotp1fW8S17+Qi+FbI=",
      "url": "assets/images/flags/sg.svg"
    },
    {
      "hash": "sha256-l/PXOl2F35iDcsdlwV5bI+hoxgKMJ5oG2nZytnnOWZc=",
      "url": "assets/images/flags/sh.svg"
    },
    {
      "hash": "sha256-qBAA9tx0G3664HtZHNx/ECPklXd3dFN1/TEKFxXVY0M=",
      "url": "assets/images/flags/si.svg"
    },
    {
      "hash": "sha256-K5DSomzWQf7NYfzwNxYB/na5yVExKbD3q6O1Ha0kVx4=",
      "url": "assets/images/flags/sj.svg"
    },
    {
      "hash": "sha256-xEry9f3mOGZgPoK6rEbeNuswgnoxTCxFEUfnr615xNE=",
      "url": "assets/images/flags/sk.svg"
    },
    {
      "hash": "sha256-YfXS6Bt8xj4GV0wsFkCpJm6jxWt7RZozGi9cPFvQjFU=",
      "url": "assets/images/flags/sl.svg"
    },
    {
      "hash": "sha256-8pI6KVL0SGPyekzduyR9vna4rwoP+iSAI+Wga5WYMdM=",
      "url": "assets/images/flags/sm.svg"
    },
    {
      "hash": "sha256-Dp9m4wnNOyytFY3uO3LRrOI8igGD+bkZevnUpdmQCBU=",
      "url": "assets/images/flags/sn.svg"
    },
    {
      "hash": "sha256-cyni8obH9doRZL9DYkQW+4FQBODn/r9Dl6vf4GdQSBc=",
      "url": "assets/images/flags/so.svg"
    },
    {
      "hash": "sha256-TGkh8PBBX8No9NHCsR+92/AEf5rbpUJpkDcBJmDDi+g=",
      "url": "assets/images/flags/sr.svg"
    },
    {
      "hash": "sha256-p1zFwvK8TUwhVRovcAG+jt1AqovIHRDuezbFbwFpKhI=",
      "url": "assets/images/flags/ss.svg"
    },
    {
      "hash": "sha256-iZF+Z/c5MTk1lCoym3Hs2u5cuf3dcMkXgbNAVjfuaks=",
      "url": "assets/images/flags/st.svg"
    },
    {
      "hash": "sha256-TuuohijPpzBakBH+Wt+am86/1tWrkWyQP9r3g4oRsGY=",
      "url": "assets/images/flags/sv.svg"
    },
    {
      "hash": "sha256-vCudh5wYYKdTPYqTL+Xfg8aF2htT1M6mAH6LHPjkzWk=",
      "url": "assets/images/flags/sx.svg"
    },
    {
      "hash": "sha256-7lGx7kVX/I9NI5PANIg96SmAWF4VdxNPhmyu2jHkeEM=",
      "url": "assets/images/flags/sy.svg"
    },
    {
      "hash": "sha256-NJPw0wjmRuaqGPPH29+NKPgAhQhChsOz6WiJXzAyqcg=",
      "url": "assets/images/flags/sz.svg"
    },
    {
      "hash": "sha256-0R4eRVflx/igdM1CjGfd/kiTUQSGgbDbr4eFzQ2KLJ4=",
      "url": "assets/images/flags/ta.svg"
    },
    {
      "hash": "sha256-pD8wUhj6JawCHtLTyQiK1kwYfSIRrJlXQMRTR1Xn3aE=",
      "url": "assets/images/flags/tc.svg"
    },
    {
      "hash": "sha256-rwcU+QaDUKE4fcJZ449pQeMAAReh3JhkVLOfoJQLgQc=",
      "url": "assets/images/flags/td.svg"
    },
    {
      "hash": "sha256-UxR2slyOPR2jpvT9P63fPmXTeXtzIBLu9sFNHq546z8=",
      "url": "assets/images/flags/tf.svg"
    },
    {
      "hash": "sha256-vNO6AosrOIk5+FENoUFzevON28VyzJG8+fpc5eoxyYY=",
      "url": "assets/images/flags/tg.svg"
    },
    {
      "hash": "sha256-vmBiYpp+ZbOjp8VyoqS+rbyq+NEBAHZz1KAuFnyw2bo=",
      "url": "assets/images/flags/th.svg"
    },
    {
      "hash": "sha256-Eh9C/YMXCvHsRLBKxjYLwIk4I1PE19rSwULxiQx0HL4=",
      "url": "assets/images/flags/tj.svg"
    },
    {
      "hash": "sha256-xfVYEzUi1BT1xcnwtAGQ4Eq0+9lsKLg35qaO+0/kvFo=",
      "url": "assets/images/flags/tk.svg"
    },
    {
      "hash": "sha256-6x/fsS1QdwmRwjpSVbN8djA3PH6raH3jGVTNjwyiafY=",
      "url": "assets/images/flags/tl.svg"
    },
    {
      "hash": "sha256-DJoiB03rhLTn3/5uEKYRSzfHJS8CPzTnKAdK1Q7CedU=",
      "url": "assets/images/flags/tm.svg"
    },
    {
      "hash": "sha256-iiMggs8BO9dzyyQQuAcDveeBhvZediXpm45Vq+sJ37g=",
      "url": "assets/images/flags/tn.svg"
    },
    {
      "hash": "sha256-KDUDJ57E00HX0AuSX0UbFml4NkEHmt/AejW8lAsz+zA=",
      "url": "assets/images/flags/to.svg"
    },
    {
      "hash": "sha256-9UP6Xpqc7HozHoa/f30hLvXtnK8cYbY8AQw86If2Xz0=",
      "url": "assets/images/flags/tr.svg"
    },
    {
      "hash": "sha256-c/KncwztkTv4e0EkMFxMEuICHzA1gmJl7+euhhlTllE=",
      "url": "assets/images/flags/tt.svg"
    },
    {
      "hash": "sha256-5kvP+LfgZQ9qe/71OZt71SgXn3oJLO8bAodhPUu8YDY=",
      "url": "assets/images/flags/tv.svg"
    },
    {
      "hash": "sha256-XlyWk45yhAXmCUG8SrQX3vKrrusJuMd++adp31d0oek=",
      "url": "assets/images/flags/tw.svg"
    },
    {
      "hash": "sha256-Lc1OE19wVLx8jJUwxm7iKpqCZNvYO2jiWMdMBA8k2FQ=",
      "url": "assets/images/flags/tz.svg"
    },
    {
      "hash": "sha256-+EGbSaxkjF7c8m+xqUOpHB8gfDnuZ7vfsNDBU4C/Pq4=",
      "url": "assets/images/flags/ua.svg"
    },
    {
      "hash": "sha256-WbE2K+kb8caLOmDvUgME39HyWlrhxPAvZzgbhHWRNUg=",
      "url": "assets/images/flags/ug.svg"
    },
    {
      "hash": "sha256-mZ2sbneNhmdKus09yf75cj76J0BITdAJRZ0UVI15mJU=",
      "url": "assets/images/flags/um.svg"
    },
    {
      "hash": "sha256-E0gI57xjJITiWZSsAzot0TZvWiFdnp692/IhmPwPY7c=",
      "url": "assets/images/flags/un.svg"
    },
    {
      "hash": "sha256-mTqHeuoAtz7uZ4iDew42OropfZv1Z1HxRi+/KIvLFng=",
      "url": "assets/images/flags/us.svg"
    },
    {
      "hash": "sha256-CXUCX8TZyRyHdfng8/YFI0CPk2DVqj3l2HzSkrWvKSI=",
      "url": "assets/images/flags/uy.svg"
    },
    {
      "hash": "sha256-uoMXIPjtH+Q16Y9XDp0F7bVEFevJvsPJftRslee/r6k=",
      "url": "assets/images/flags/uz.svg"
    },
    {
      "hash": "sha256-S3JFGVhJ5AJRYu2L6mqNQx2+HNsk5c+gCMoBcYOOBx8=",
      "url": "assets/images/flags/va.svg"
    },
    {
      "hash": "sha256-jtzrLuSP8n0244o5NEgxuOjAhNjXFM5EYbMcW01av64=",
      "url": "assets/images/flags/vc.svg"
    },
    {
      "hash": "sha256-uMI4KuFNKRNCoxqjjci0zZfRsJlsLAUVxRX9Q4DYYWw=",
      "url": "assets/images/flags/ve.svg"
    },
    {
      "hash": "sha256-DtiwnDGVJbdbyMjyhCZPBjJcXvoVDp6lwz+K2NBmTRk=",
      "url": "assets/images/flags/vg.svg"
    },
    {
      "hash": "sha256-tWgsVkBoHpS5pMDQHmrr8zryhJXvo4hlFJf2++vGeKk=",
      "url": "assets/images/flags/vi.svg"
    },
    {
      "hash": "sha256-Ws0ZH/923mmKF0B2xTfLGZd8O0vTyP6w9DzSIQ8rwY4=",
      "url": "assets/images/flags/vn.svg"
    },
    {
      "hash": "sha256-YyYe5fdhyKtQWMToSQRuwcEcmLcumILF3trdzN4jp08=",
      "url": "assets/images/flags/vu.svg"
    },
    {
      "hash": "sha256-ogB/CR0JamLB1f4avimdgmyNda1MW8j/+STqETsVnYc=",
      "url": "assets/images/flags/wf.svg"
    },
    {
      "hash": "sha256-2PMc07oKkSJ0vebgY7quoMdU9CDnyKgf144rNBzNoe4=",
      "url": "assets/images/flags/ws.svg"
    },
    {
      "hash": "sha256-k1NXVBYRdwB3hiDCwbEJXD64xyLha6nANespisO6OQ0=",
      "url": "assets/images/flags/xk.svg"
    },
    {
      "hash": "sha256-ytYXFd6W9vA3ylLbcqkyem7UKigSAiBObdk8kUrkptA=",
      "url": "assets/images/flags/xx.svg"
    },
    {
      "hash": "sha256-JOVIgEPUThdc/Qz7dz7gCVDEBcw6n61ywFKLIQj6dyM=",
      "url": "assets/images/flags/ye.svg"
    },
    {
      "hash": "sha256-p3ekvUzhHnSfdPt8+I4olYdO0qrO38MC+OnUL/pDk3I=",
      "url": "assets/images/flags/yt.svg"
    },
    {
      "hash": "sha256-SwPyGIHd6zyHBnsDK560RRfwVcIaAY7oV0v4+X0rUfE=",
      "url": "assets/images/flags/za.svg"
    },
    {
      "hash": "sha256-ptD8B6Sy+NrxY3UkUmG/nUVhoQKTXebMS5t8kPm39EQ=",
      "url": "assets/images/flags/zm.svg"
    },
    {
      "hash": "sha256-v+tca23PWjxP/AJ2l06BFdBRwFrWqZ1a9D837DLSv3Q=",
      "url": "assets/images/flags/zw.svg"
    },
    {
      "hash": "sha256-dsKmNXsJjcNWx0nqpwWQ52KjC6Fcv62ktx4/vcQ6iAA=",
      "url": "assets/manifest/manifest-128.png"
    },
    {
      "hash": "sha256-WybxmCXlR8jvzkm1vDel2kU8/bp4jy5CSgq5okLl+Yo=",
      "url": "assets/manifest/manifest-256.png"
    },
    {
      "hash": "sha256-7rxxQe9Nq2pNb/khYlJM/ZaKhvt3ZHST5WMyv5m4FwI=",
      "url": "assets/manifest/manifest-48.png"
    },
    {
      "hash": "sha256-vqnC4Q5X3aNOvD+Kh+7rgST2bSw4x5+4tol4gznMwck=",
      "url": "assets/manifest/manifest-512.png"
    },
    {
      "hash": "sha256-tQtnVxG14a/YIrnO+YvG/uT95Hm90pxQ8pmaVszvx7Y=",
      "url": "assets/manifest/manifest-512.svg"
    },
    {
      "hash": "sha256-pHQDZs7dmWZ6Dkw4ynepAi95Tpt9rYNp+bCPaMQvsuY=",
      "url": "assets/manifest/manifest-96.png"
    },
    {
      "hash": "sha256-WVbMd6lfAdoMXlGUUrKDaXCw4doMsu4iGquYSQ8GCQA=",
      "url": "assets/symbols/msgkinds.svg"
    },
    {
      "hash": "sha256-z03TutGpNTe9YsttVwOpjDaGs/pEc8CCML+U71hqp98=",
      "url": "assets/symbols/symbols.svg"
    },
    {
      "hash": "sha256-F84SCmM2X2k7tMAOvu1aqKRRgsd/pYnTy9kBZo7BYzI=",
      "url": "content-kit/content-kit.css"
    },
    {
      "hash": "sha256-nBHf1K8J09bw1SsRInwCAFx2B7s1G/+r7IoEqsw7ngg=",
      "url": "css/_radzen-fix.css"
    },
    {
      "hash": "sha256-ndNbTJhnfIQPzZsWFa9u3PMvIhVQoOpiUtML05Ev/ac=",
      "url": "css/animations.css"
    },
    {
      "hash": "sha256-nfbt6jEL8UaMhYL3pxkZBKxCtk/pABNVpUGk702KiTw=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-d8FK8DmdFPzPGkCfBsvlIJKMX3R3ylPz5U3Lj7XxWyQ=",
      "url": "css/typography.css"
    },
    {
      "hash": "sha256-iYy91t0XqCJN4/p63TK0gIh89UrLAgYyN1d87MGHSz4=",
      "url": "index.html"
    },
    {
      "hash": "sha256-F9t8HNWlPeXaZ2BZ5fMJPsYNJLT1ENstVrNG8NWILAg=",
      "url": "lesson/index.html"
    },
    {
      "hash": "sha256-g0IxWXcSZ4I0ujMG9VWv9SnfKWRljo+Iz/LmvFXTQds=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-C4j70op39e0YfOrWkFxjwD1PHlc+6mDa4pZde9vEKlk=",
      "url": "script/798.97c751e2.js"
    },
    {
      "hash": "sha256-379vlRJq6DELfEiYeoShX3ZRd/MWQOONasRStYgy2UI=",
      "url": "script/appdb.js"
    },
    {
      "hash": "sha256-Arj6gARyvb1PAh81Q8y7LB9YzKfDzFiscmfoLKs3ePo=",
      "url": "script/bookrt.js"
    },
    {
      "hash": "sha256-HTpXfTyUySfgL+BoFlfecHA0BPN5bU9pIqz5PYfZoEc=",
      "url": "script/bridge.js"
    },
    {
      "hash": "sha256-ufQ9NZXnGZiIy8NFFIjxtVwzaKadbItlhr9U13sEoko=",
      "url": "script/install-worker.f47b38a4.js"
    },
    {
      "hash": "sha256-vDYkT00rdx+dCk1K65/ZRNakNRQHolJMT71uDTmqIaQ=",
      "url": "script/livekit-call.51f0dc83.js"
    },
    {
      "hash": "sha256-j/RmzFpuPcZyISIlgeV2xIjHiFNT0PfJy2Sa9fKZblE=",
      "url": "script/livekit-client.402790a9.js"
    },
    {
      "hash": "sha256-rXpTrxouwRkVAfAnWhiJw1hvZnSIv521iQ7c/gSQb+U=",
      "url": "script/reg-agent.js"
    },
    {
      "hash": "sha256-UHRxAWUmqB84M7LH9RNsKmMxz7X6nVbGabH+hoCt8KA=",
      "url": "script/sw.js"
    },
    {
      "hash": "sha256-EDg+bPvcoB4ib9XdGpf09xF77c0LN8JIyQ0WsX+G0NA=",
      "url": "script/uninstall-worker.7d46f8cb.js"
    },
    {
      "hash": "sha256-J/4AIOvGspqV6uXOJaaUrBYH4p3KeKra0yfm+uvoy20=",
      "url": "script/zip.83b79aff.js"
    },
    {
      "hash": "sha256-/A/GdzdN+eLbCTLdf8wURUTLuubOtZ9eTvvleFLAF80=",
      "url": "vendor/h5p/fonts/h5p-core-30.woff2"
    },
    {
      "hash": "sha256-w/PpackG3S++feD5SGrzISE/FCk2PhW16UorxymlY98=",
      "url": "vendor/h5p/fonts/h5p-hub-publish.woff2"
    },
    {
      "hash": "sha256-lZHIxMboo6kPVK/7P8GXDPXpa4LAnL5dCHoDXpXUL/w=",
      "url": "vendor/h5p/fonts/h5p-theme.woff2"
    },
    {
      "hash": "sha256-b3UCWFb42xshhunLib6d6YlJMsi3sg9N9eZZFv9xTjQ=",
      "url": "vendor/h5p/fonts/inter/Inter-ExtraBold.woff2"
    },
    {
      "hash": "sha256-U7sguikuKsKKB3e/D1bzG5i+Qyo8wENZ4utgjHWDScc=",
      "url": "vendor/h5p/fonts/inter/Inter-ExtraBoldItalic.woff2"
    },
    {
      "hash": "sha256-sxla8PsUNo0bOxD7nT/lA7cWPqCDhZ0u5VO8dNoHwyA=",
      "url": "vendor/h5p/fonts/inter/LICENSE.txt"
    },
    {
      "hash": "sha256-Rq7ljPJz3z7bsZ5E22beWocQb+ZB9X4IVz5iaIdXoAM=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-600.woff2"
    },
    {
      "hash": "sha256-66MeHa8tYi9nlYY15TFiBI8TVsFWVcUDuY1uzbav1VM=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-600italic.woff2"
    },
    {
      "hash": "sha256-CdVUqyfhsCziXW9fr3Hi4H53wovrQBnbz81D7HVY098=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-italic.woff2"
    },
    {
      "hash": "sha256-IatOkaYrHIba972jgY+M8HIfkc1mSp0TWSPB7WtpTpA=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-regular.woff2"
    },
    {
      "hash": "sha256-h6Mw0vVs/kcEMe7XmW+lQj9pTHnirXxMUVrHW8mjQNY=",
      "url": "vendor/h5p/fonts/open-sans/OFL.txt"
    },
    {
      "hash": "sha256-MgKHgtn3J6NAc11SerMJ41oTKWJ70PRRPn7U5FGog1k=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-600.woff2"
    },
    {
      "hash": "sha256-lOjKDm7udP+H30Jx/zqARBTwtE1Td/TszUjWjxfO82w=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-600italic.woff2"
    },
    {
      "hash": "sha256-c+qpgwgjhV8VbNTgsn5wlvfmI7oCa7U2ZkD7BUDN0IE=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-700.woff2"
    },
    {
      "hash": "sha256-q2UUw/DKZ4I53wFGbDqjTjjwBuPNoBakCM//CcxxxQc=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-700italic.woff2"
    },
    {
      "hash": "sha256-5NyaoE2YGfxDRayVRIMSePP/2P9K+EARmajI10Esw1M=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-italic.woff2"
    },
    {
      "hash": "sha256-YWuYcGsCsnROD1HfvgcMVr/G5z4JY7AgDpkI+Fam494=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-regular.woff2"
    },
    {
      "hash": "sha256-5t6zni0BFIaQgLrN9AktyzDPLOIPi948O6ivA1+obgs=",
      "url": "vendor/h5p/frame.bundle.js"
    },
    {
      "hash": "sha256-uOxMrprtoVTGhyYokeiQQUTeV/+fJb5it4KIvy0kaU4=",
      "url": "vendor/h5p/images/h5p.svg"
    },
    {
      "hash": "sha256-58ZlXJpC6HJzqtnreQET23N85fEaHAdsInhYT1Kkc70=",
      "url": "vendor/h5p/images/throbber.gif"
    },
    {
      "hash": "sha256-bKs31WFecPzanL4RYJ407d6CGsDF6aVROZaeDnHVums=",
      "url": "vendor/h5p/styles/h5p-fonts.css"
    },
    {
      "hash": "sha256-qTalyLFNN2adixctC8Ag4ORDXw08y4uTXRe4GyhDQ8w=",
      "url": "vendor/h5p/styles/h5p.css"
    },
    {
      "hash": "sha256-1CldwzdEg2k1wTmf7s5RWVd7NMXI/7nxxjJM2C4DqII=",
      "url": "vendor/mathjax/tex-svg.js"
    }
  ]
};
