self.assetsManifest = {
  "version": "OcODceo2",
  "assets": [
    {
      "hash": "sha256-+uqDzAlHzjlwn+abgzsNzvwxLsp7n0RQJXlAhUNPjTg=",
      "url": "CyberShelf.styles.css"
    },
    {
      "hash": "sha256-itxgC9CUXgA0s57EK2bjpHhRABlrtO8ndt+ThYI7Lus=",
      "url": "_content/Microsoft.AspNetCore.Components.WebAssembly.Authentication/AuthenticationService.js"
    },
    {
      "hash": "sha256-rN9K+kOFG579iiZefcpwdJ/KIcCkeomybswY1BDUm9Q=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-aIocV1fJN46SwxcRcdRkQDnKdNA/GBeB9WfM65xCVqk=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-3TxU6Q5yHJAP4dEkQxetq1LdzBU3Z1dUu5wdEy8Iatg=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-e2t0XEvHjvnHz0+YyBm1WzS/2xM0xQqkmsqWzqNL7bI=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-vgChE+Tg3uiyY5YwR4ct3Mmb44soz0648J3PQAyTUTU=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-cn4tYaUvJXmtUOixxyvsDd1GgD3dxht2G6WaQ9ugIM4=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-4ZhsA5It6DSxM0+FQXNEnYQxstRyADciid1036IIYKw=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-l9kMxJEo8TzgFnIS2VNVb3CQq74PNdVLWt4K4pwKyZs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-u+ZZ/beUAOubCGdvebfogD+/jSrEXzKzjTyJHl1yCns=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-HJsAypWKyLz1pRfBkH+6hWEiEqOFGpnf2yRcmvfHLK4=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-jQnJQgL7D887Cr/N+ZKn+KSSllDVogMPO2Zo6qUi91A=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-YeMQZuEajn7fk7zwwvz+CuBnXwd37R5EJrE2WGPZdfE=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-0q+uxXtDeinEdGv7d0nx0BTfgDsKyPT81DPNYyo0T3M=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-XXq4AWzZdI1TcMOaoy39k8fKLrOiUNgQ9Hh2OQdfs+k=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-qR6n4PLaYLro0GUmrCDi2RL31tFA//lzfRkl7UOkwhM=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-OQwGRlu7Ilnz4pT8G4AULrm7TrRxKnIZXCvMWon6w2I=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-zr/DC++GRcAVwRD8WIa1Txz5ofKos+WZOxErN9qjS0k=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-+u+2q5DSbEwvoeFlPHaMWn+fa4d/Y4wfPxyftW0zmMM=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-3oVE9QoDWXxlpvsI97eUMrnDh7/+BeUg6hKM9A21TPg=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-6JpprDLklK3UfMPPCZc3brkTcpiwaDPQGn6MKTRaCEs=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-aDl81ZduIuqUVrCAPZmPBzU7uQNTvWSvqUW+XRaJy2w=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-PWhS0bBFhKeg2GutRpftqPeVtr59oeXfOslhwdHDkQ0=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-soBqVeDOe3AZki4mQ1fPzAk735KqEsg7WrIFlX30woI=",
      "url": "_framework/AngleSharp.2coidq2lqm.wasm"
    },
    {
      "hash": "sha256-4Diue02BcmgMCs2GbdIncDbObwTBOLgvd6XPH0wuoiE=",
      "url": "_framework/AngleSharp.Css.wwsq4crpi6.wasm"
    },
    {
      "hash": "sha256-eUPO2Hi2YsNUamlzEKm15v5ZgFVhogsa8CfHBU4HHJo=",
      "url": "_framework/CyberShelf.tvcxkki41i.wasm"
    },
    {
      "hash": "sha256-f0uhXaNzSHCguW7IErTRjeiGQXPWEWl5p/eehMZkDdc=",
      "url": "_framework/Fluxor.9yjucuf12h.wasm"
    },
    {
      "hash": "sha256-DBC32gXCmb31ELcLWyN0VaYPespDZiNUhIL276D1X7Q=",
      "url": "_framework/Fluxor.Blazor.Web.4opwue5a6j.wasm"
    },
    {
      "hash": "sha256-GbxNXXnF23iB3vUqJtKENGudNXAXNET0d67a4hY6wAE=",
      "url": "_framework/HtmlSanitizer.nkc90zzwkj.wasm"
    },
    {
      "hash": "sha256-LAeLtTGhb4Wj3uWzATgpnJJFGn51yTEx0Gjm5Hd7RzU=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.or3v0pxzpe.wasm"
    },
    {
      "hash": "sha256-p6xdcXMkvuP+XnsZlSFYGgBfy0mnz+1aTeRvdDdj0u4=",
      "url": "_framework/Microsoft.AspNetCore.Components.5p5yygixra.wasm"
    },
    {
      "hash": "sha256-Cfe0kL/10AdXcfURmF+K/cIaCnDnZlhWxkGtR3rFvyM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.1uh7hs0g6y.wasm"
    },
    {
      "hash": "sha256-Q+MIbtSCwGXn7JvqqjAIWrLLnOpJ3gTuU1OfZ2mp6xY=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.1bbm2uw7vc.wasm"
    },
    {
      "hash": "sha256-foBM31f0PIpy1GN3Iihbv92GqtGGIm7fVLatYkaQ+VE=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.q1cq1ogfaw.wasm"
    },
    {
      "hash": "sha256-kzEqK/acUrOwF8D7mWPVTeiiG42mqqhBC4boj4AmmwU=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.lmg5zerlez.wasm"
    },
    {
      "hash": "sha256-HDof6DD8xtU65Q/RhVPKVaW2y00xd8I2g3gxAneot/k=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.8t0g6je4cu.wasm"
    },
    {
      "hash": "sha256-YGGtORB7Ejiz/FbdNSzitIR5Ntlbp6WID3XiylriLWQ=",
      "url": "_framework/Microsoft.CSharp.wc9155ydjw.wasm"
    },
    {
      "hash": "sha256-4yiF/uCSo6eZ20smSb0Rlq7rKaCIwmAKNDMGzpz7OqU=",
      "url": "_framework/Microsoft.Extensions.Configuration.9d8zud9wr7.wasm"
    },
    {
      "hash": "sha256-13zFSTFrGK1uC2iFNhGNX9w7MwAUsEzdVsG9nn67bEg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vy7qudiyob.wasm"
    },
    {
      "hash": "sha256-JNFeJy5qsewJSP3tDVETS/NqP3p0sOrJzdvOMC2R+Kw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.gptru1g2ud.wasm"
    },
    {
      "hash": "sha256-niwb2sZskJ7wsZsNxfs8leRiqjwIuv7eqfar1dAjILU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.qiwbq8ugx5.wasm"
    },
    {
      "hash": "sha256-WYob3eJ5JZ5ET5XXcpdH1/7t3wwTlVUO7ByA3A/XT8o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.556xh3l82c.wasm"
    },
    {
      "hash": "sha256-ZM0ouBgQS+R81BR8cTXHLCZOZkg6dB2jVDXthIkIMGA=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.0p2nkb42en.wasm"
    },
    {
      "hash": "sha256-FsDD1xCAGbahHPs4EM8NfzzGXatQxfOTX7m8HL6nC0s=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.2uffu1oll3.wasm"
    },
    {
      "hash": "sha256-98KQRZr9w7MHE1gtXgScbI/snaA8ogs4Zcnnk9ZhsMQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.bba307b5bn.wasm"
    },
    {
      "hash": "sha256-I5sbAciI1nenzhMpi7DIqGnntCkXe8VxQ3CNA6DxNcw=",
      "url": "_framework/Microsoft.Extensions.Localization.9xfpsryliu.wasm"
    },
    {
      "hash": "sha256-TgSM2E4IL/DPx3A8bjaItE4hMPi+mrM9JQ/Mj6+2aK8=",
      "url": "_framework/Microsoft.Extensions.Localization.Abstractions.ikd0fm3c5f.wasm"
    },
    {
      "hash": "sha256-A8FVsy8d9iCgpNrcA5oM8mG+DIXGHtTffb9WlkTr3QE=",
      "url": "_framework/Microsoft.Extensions.Logging.5ucwms7sds.wasm"
    },
    {
      "hash": "sha256-lIogVE4IjSJ31gg6y5K9Tf2n6QlvZtvhVpbNIgI0RPY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.kgwp2einjb.wasm"
    },
    {
      "hash": "sha256-6g+EYKpGaJxzsRmZTykgd/G3J5WmMqNb9kF5yTabxZc=",
      "url": "_framework/Microsoft.Extensions.Options.uj2skkfzid.wasm"
    },
    {
      "hash": "sha256-n9kiqxmELAr75j81XAvmMMKJ0o2jNzjY4Djom5VsRSg=",
      "url": "_framework/Microsoft.Extensions.Primitives.t9gw8p8qof.wasm"
    },
    {
      "hash": "sha256-b3oDx6CnxrlJd3wQYFL7BPJaC0gtnVabH6OvSqSmP+0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.r99mmn9mmt.wasm"
    },
    {
      "hash": "sha256-S1jJv+AZDuSVz9qBKOY7vdHxN0s5Syn5tGKhTHFjca0=",
      "url": "_framework/Microsoft.JSInterop.l4xclch662.wasm"
    },
    {
      "hash": "sha256-9RDxFqlwwEYJMCMCSrVHOx0dlrBeTNSn8B/izhAPG2o=",
      "url": "_framework/Radzen.Blazor.h573efuu5x.wasm"
    },
    {
      "hash": "sha256-Txh+XJAQztWpShnI84UIZpRNhz7Qkw08H0YoXrYjvHo=",
      "url": "_framework/System.Buffers.92qr7xas64.wasm"
    },
    {
      "hash": "sha256-MMkTEpTZPMnc9a1QCAbYvWh8hyZJaCYnntT+UPXXtIU=",
      "url": "_framework/System.Collections.0ceho74gax.wasm"
    },
    {
      "hash": "sha256-WKbmv23cDlDaSxuVO7/Fsaa09WYSHPfFr/VSKPXsyx0=",
      "url": "_framework/System.Collections.Concurrent.kxzzhmjj9z.wasm"
    },
    {
      "hash": "sha256-lNGbEuZlXlQMjcIDaL/L6TYFBKn6VhwjVBKx746qtK8=",
      "url": "_framework/System.Collections.Immutable.gpw00r6umg.wasm"
    },
    {
      "hash": "sha256-7c1BMCBEYB0zsmb1njvP5YyJTpHJSY6tu2UT0u5vseE=",
      "url": "_framework/System.Collections.NonGeneric.xvrf7vlozt.wasm"
    },
    {
      "hash": "sha256-n8NOD3yrGBmBYD7rUS9LyI72W8C/yrCfwI7vTHXb2LQ=",
      "url": "_framework/System.Collections.Specialized.txmxmtm6kv.wasm"
    },
    {
      "hash": "sha256-e5fTQl1rPXMlXGZqStM5bvN9f2eY4J469jgsvXVIrb4=",
      "url": "_framework/System.ComponentModel.Annotations.vn6fwqkzom.wasm"
    },
    {
      "hash": "sha256-xoKxYUCRKs636h8bZ2fMS1zEg8nviGYpFyzlzLbkpmI=",
      "url": "_framework/System.ComponentModel.Primitives.agbtinp8h7.wasm"
    },
    {
      "hash": "sha256-mXY2RApGRAItL0KlpQPGj6rouGIrUZC1q/cua/ZdRX4=",
      "url": "_framework/System.ComponentModel.TypeConverter.lpo6on2vi7.wasm"
    },
    {
      "hash": "sha256-G/6EwBzWPMxU/4/py+wFnYln9lhcjEBQNpoWxkdNym4=",
      "url": "_framework/System.ComponentModel.vvuj3malmy.wasm"
    },
    {
      "hash": "sha256-VBZ/nXz8Tji9jc8CkQfwVLXEu6gLJ0zdTSyZihZOn6s=",
      "url": "_framework/System.Console.skwboee6kc.wasm"
    },
    {
      "hash": "sha256-6tqPDxv8LgQtZVuDu7pCBH2aS8fKRZvrTKeOfByqp4k=",
      "url": "_framework/System.Core.69mx0zocjz.wasm"
    },
    {
      "hash": "sha256-TLbNqTb4JQ3RXL8p89PUmBGYka+5ml6wiC+Vw6X46hk=",
      "url": "_framework/System.Data.Common.kk5a3nz9i6.wasm"
    },
    {
      "hash": "sha256-3N6zMCi1yaqQsDfpC0VtrCrIMdKCO/lnKHXYRWmMF50=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.09ahfhgitn.wasm"
    },
    {
      "hash": "sha256-pD9Zvy5LbVir0BSnnFx7GtXQYIeMbkC2JWG+oXhPGd8=",
      "url": "_framework/System.Drawing.4q3qj66otc.wasm"
    },
    {
      "hash": "sha256-WYbuJ2NFqttZBGfOpRo+xoMbQaizCX9SzxM8firgDlU=",
      "url": "_framework/System.Drawing.Primitives.9w91me9toy.wasm"
    },
    {
      "hash": "sha256-OvqyZh2BYv1heGP0+hgeRqw86zml5gvGbZqdTSBqZwY=",
      "url": "_framework/System.IO.Pipelines.unqpbva9an.wasm"
    },
    {
      "hash": "sha256-d4KQ0HYFeAB4Pv7CSt5TWuQ21qDfuotD0wuVUW0CG9M=",
      "url": "_framework/System.Linq.Expressions.jpyfxpyl20.wasm"
    },
    {
      "hash": "sha256-DkzMSUDEnYa3l7fyY93nEMOdhtcG2YvgPlb8X7ciuac=",
      "url": "_framework/System.Linq.Queryable.yk0kobxtrc.wasm"
    },
    {
      "hash": "sha256-xcClaKA7rIGBtsL7GLT76zZ5Tud27yJlxbD+z0NwWW8=",
      "url": "_framework/System.Linq.b8pu018hrt.wasm"
    },
    {
      "hash": "sha256-Va/ILK93NXUE3bT18ty2/7WVPrLFbCtPxAP2PwkEIA4=",
      "url": "_framework/System.Memory.9n1k6xw6qk.wasm"
    },
    {
      "hash": "sha256-Y5HeCC3JlUXWW730tK5goZPahTR7blenEvZXnl7FbWw=",
      "url": "_framework/System.Net.Http.1rhboakq0y.wasm"
    },
    {
      "hash": "sha256-4mj2bZL3P7eYiSWksIirSfiai6w3/BLR6rlthdFenpE=",
      "url": "_framework/System.Net.Http.Json.yzhwk4lkqx.wasm"
    },
    {
      "hash": "sha256-R3QhGI/lnXI8WJlnEqcJBOYJsDP7Y+zGotaKcdHndrA=",
      "url": "_framework/System.Net.Primitives.bzt6f61d8b.wasm"
    },
    {
      "hash": "sha256-Ei50ZEJ0v2A9NV+8iuk1gocBwW6KLEf8IwsF6Py6rBk=",
      "url": "_framework/System.Net.Requests.6v7purlf4j.wasm"
    },
    {
      "hash": "sha256-YyZyIquUwn8ZKli/Fms3533JUJHS7afuS5M58dFcYMo=",
      "url": "_framework/System.Net.WebHeaderCollection.zggssa66ip.wasm"
    },
    {
      "hash": "sha256-9wBujB+ZLVvh3p0ZcKZ7wZ1hVJg+hMm3bMT5CP0cWYs=",
      "url": "_framework/System.ObjectModel.ldq2ds3fa3.wasm"
    },
    {
      "hash": "sha256-vOCFGKYrkeA4C2sADHZ+2FRbRoVXMMNWlCETKOifGyM=",
      "url": "_framework/System.Private.CoreLib.03pf44evpp.wasm"
    },
    {
      "hash": "sha256-VfsFY3xgd742dC3uHX6m13p8vE/M7wXp7bW912OChGU=",
      "url": "_framework/System.Private.Uri.loq5tqgkwu.wasm"
    },
    {
      "hash": "sha256-1n/w0QQNpBFtGQhqwdtd8J8DcPubZlMbb9xUu8K2rfQ=",
      "url": "_framework/System.Private.Xml.Linq.eu1mpxr5f5.wasm"
    },
    {
      "hash": "sha256-QoQy7BVTkxgrFxgfmE17hjwNsYcX4iZjHegdOcJvYe0=",
      "url": "_framework/System.Private.Xml.mbiek3rcq3.wasm"
    },
    {
      "hash": "sha256-ADwVh2CxWm0iO/rnJBn+ePDnMggqFrjf8/QdvLOjZwc=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.knrgwrqxog.wasm"
    },
    {
      "hash": "sha256-3r1UTwoxFA6w/bRvZhSPZdn5oQSMN3mQfaWImM3XCGo=",
      "url": "_framework/System.Reflection.Emit.mn176mar7p.wasm"
    },
    {
      "hash": "sha256-7Bw1sNGIBmW5LAauS9CP1ixKUAhXda/bTarwtiIXaag=",
      "url": "_framework/System.Reflection.Primitives.wp31qs1bml.wasm"
    },
    {
      "hash": "sha256-orXDJ+k47PinKZ2FtzefqtlGM6rB3uolse7A5ghR1QI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.2j7dj8dwvr.wasm"
    },
    {
      "hash": "sha256-jItyf07BQiHuk/dd+9ol08DeM/6KIY+QMO598PW8c1A=",
      "url": "_framework/System.Runtime.InteropServices.sqnltnlnqh.wasm"
    },
    {
      "hash": "sha256-JG6oSE3ZRgdJpALH9Y9yPUGBsHw8P5O+oX6gCrIuxSE=",
      "url": "_framework/System.Runtime.k0dhut220v.wasm"
    },
    {
      "hash": "sha256-Y4Tw3nmRD4khUzTTcc3Uud4xwMWN0kwXi0xIWQP++XY=",
      "url": "_framework/System.Security.Claims.7jr48mcdo4.wasm"
    },
    {
      "hash": "sha256-i67HIiXR6zyoIAta9C5mqDE49JlPHnaZO1ektxLqmXc=",
      "url": "_framework/System.Security.Cryptography.lgu1xsxxgm.wasm"
    },
    {
      "hash": "sha256-ZEeCNxLy6wIM9j+KPK6NWmMyFffz4yPB6toQP72CG8c=",
      "url": "_framework/System.Text.Encoding.CodePages.48gpt7faa9.wasm"
    },
    {
      "hash": "sha256-jOWlxH5IHB+wt1a7ELaVPr5BSus3YpnBrnb6Gw8qZ4k=",
      "url": "_framework/System.Text.Encodings.Web.8v9qmojk51.wasm"
    },
    {
      "hash": "sha256-xRg6XAbSZTV7ls5umR8fvXNWe1zbgj1zs7sWWljmHGA=",
      "url": "_framework/System.Text.Json.l4q6zrstmb.wasm"
    },
    {
      "hash": "sha256-j3XxK0EFDX5M9SdRS81OSURZqaBBok/1ZgU/d/c5bFg=",
      "url": "_framework/System.Text.RegularExpressions.v0b33esa9w.wasm"
    },
    {
      "hash": "sha256-R9wysr1cE6YCuokS6LAzlIDM4CLpp83qCz3BMH6KaLg=",
      "url": "_framework/System.Threading.35pobbx91w.wasm"
    },
    {
      "hash": "sha256-Vck8BP1Lv1QnlHlYrmhXzSTfF/qBEtF68MtuJnK/Lpw=",
      "url": "_framework/System.Web.HttpUtility.54w7790oyf.wasm"
    },
    {
      "hash": "sha256-ychfeUH0ggf8nxM3GDZvGyM5rfO3tpXNJnb5MepaEKw=",
      "url": "_framework/System.Xml.Linq.3dip6ic8mi.wasm"
    },
    {
      "hash": "sha256-G2EDsVbsj4CD0PiwYlJ16p7/IZQpMK2BBxjC4JmWx2E=",
      "url": "_framework/System.Xml.XDocument.5c3kddlaox.wasm"
    },
    {
      "hash": "sha256-QZM96Sbw2BYre4bcT9tJXUPU/9h0LdgAPwGMigVXC8g=",
      "url": "_framework/System.x4983syfn1.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-4c90rubc6vxEjOjI4k9DqACuznLU7UbGnQMjy3AaQLg=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-xMC9so8ZaPfSqZFihOSsvd3GaFXv3wNkLZVwRi5PNRs=",
      "url": "_framework/dotnet.native.wbx6pmkdcw.wasm"
    },
    {
      "hash": "sha256-A1labT5SXTlEoelZ96LFb0Pb04ubwsi8EcdS9RG7LYs=",
      "url": "_framework/dotnet.native.z49vxemcj2.js"
    },
    {
      "hash": "sha256-YyudibIWETMKrLb+nAZdJ+xDY7HY6BWf6s32UAdcvCU=",
      "url": "_framework/dotnet.runtime.r2kbxkuujc.js"
    },
    {
      "hash": "sha256-tO5O5YzMTVSaKBboxAqezOQL9ewmupzV2JrB5Rkc8a4=",
      "url": "_framework/icudt.oh1zvcfom8.dat"
    },
    {
      "hash": "sha256-J0DIAfov1MKmyh/dD74pMNZbSq2hgnSgHWGK2JLhSq8=",
      "url": "_framework/netstandard.1ajx08key9.wasm"
    },
    {
      "hash": "sha256-O9R1YhKnRQM8QvfgcMgM5HmLIl5lv94p+sDqIoS4sN4=",
      "url": "_framework/ru/CyberShelf.resources.bkyxvak6av.wasm"
    },
    {
      "hash": "sha256-Fs/DJ7hZHYllMX18MqfNODd8WndkrJSSRtSkfsHleSE=",
      "url": "_welcome/bg.png"
    },
    {
      "hash": "sha256-pLL8BGIXSBCI8Us9oblGIp7iCGJD4i00OY3skwbvNMc=",
      "url": "_welcome/logo.svg"
    },
    {
      "hash": "sha256-qt5wpHhHU106ZPM1lSJEWpn6S2XR/ZSy505/RpsPGY8=",
      "url": "_welcome/welcome.css"
    },
    {
      "hash": "sha256-EGaOOmI0Qj0gbkariWjoy/zTTtPDSr26hv4KrVPBpS4=",
      "url": "_welcome/welcome.js"
    },
    {
      "hash": "sha256-D5DI3iXXRvM1vEDXhMFesk08Qviey83NTO6j2vxmxOA=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-nqgz38BzEuFd/Rh5vGSz/gIq4zYFkxKoGYN6+IeEUes=",
      "url": "assets/about/egor-avatar-square.png"
    },
    {
      "hash": "sha256-ykKcE46lCtVmU117HctNJ1cGRA7lLd6NGQiqb2dQ10M=",
      "url": "assets/about/grigory-avatar-square.png"
    },
    {
      "hash": "sha256-9zB85X8JGJ2Xv1RRXZdvMSMd+JOeXGvWXyGrXKwwlZo=",
      "url": "assets/about/logo-neostandart.png"
    },
    {
      "hash": "sha256-0oaNqnXVHlELgtvglOnqqlNhKavgYCgXyM1FcdiRZlc=",
      "url": "assets/about/logo-uppercode.svg"
    },
    {
      "hash": "sha256-0sew+EhYdt7akEDPUluIVih3di8s0PLKP0BC2tx9qrI=",
      "url": "assets/blanks/folder.xml"
    },
    {
      "hash": "sha256-UZ7JfGs/eDtdI6ThAVMMx6LNAzkTyWbN/Y4U27Q9SII=",
      "url": "assets/blanks/htmlpage-p1.txt"
    },
    {
      "hash": "sha256-XHnlDK2/ainTHe9BwX3w9NLUKgl3FAAMMgczCFjEXSs=",
      "url": "assets/blanks/htmlpage-p2.txt"
    },
    {
      "hash": "sha256-4ERHMvU2qMwV7S1O5e4YG2Re3HNRQr2+FeKYQc55+ZM=",
      "url": "assets/blanks/package.xml"
    },
    {
      "hash": "sha256-fSXWSZkGL8ZupiB1D8tXgnQUXbdfe9lS2sL+m6kJJLw=",
      "url": "assets/blanks/shelf.xml"
    },
    {
      "hash": "sha256-fg0kdJvp9yqzBCK/wsY28qy0CyraUABjFlPh8NnoxgE=",
      "url": "assets/blanks/suite.xml"
    },
    {
      "hash": "sha256-6YZiRiSDvx5+t1jhNt0H7dCKA9rLeCqTAsM3Fo/+MIg=",
      "url": "assets/countries/countries-en.json"
    },
    {
      "hash": "sha256-jX3YaIBikQ0GzKwueRqkPOi2JWMZzr9zDM2iFkj6aaI=",
      "url": "assets/favicon/favicon.ico"
    },
    {
      "hash": "sha256-8CZK/OvxxIrj0vw/I2oF1YgWvRS43K8chz2AxO1UDcc=",
      "url": "assets/favicon/favicon.png"
    },
    {
      "hash": "sha256-Isfm2CngKPmPqhxbsBXyn0xy8gIFGmf4K40UZaUH90I=",
      "url": "assets/h5p-player/core-fix.js"
    },
    {
      "hash": "sha256-lVDoHEIlOTk0jIlD78BQfcUCg+dq5JyVfLBBdc2KmuY=",
      "url": "assets/h5p-player/player.txt"
    },
    {
      "hash": "sha256-Q/uAW1r8RQo5bFqfZvHtnqqju6dTokmjfdai9IleCos=",
      "url": "assets/h5p-player/strings/en.json"
    },
    {
      "hash": "sha256-58sFyvpjMKdolbKb5IOOJac5YJX1vL57BOfgxI1m/f4=",
      "url": "assets/help/quickhelp-en.xml"
    },
    {
      "hash": "sha256-z+ucuS9pow4qFOJ/ovbzO7ZgNF5ixorhBKFpb8swdnE=",
      "url": "assets/help/quickhelp-ru.xml"
    },
    {
      "hash": "sha256-t1YB7amYWYafBzjgXdZVqp243XpIxS2zU0SQX4pNQ1U=",
      "url": "assets/images/distribs/distrib-01.svg"
    },
    {
      "hash": "sha256-a0rGNBW9r94xGlK2PJx6AAFSVWIBqgKyB8yt44/H35M=",
      "url": "assets/images/distribs/distrib-02.svg"
    },
    {
      "hash": "sha256-wipD6J8mNuzeThfRxzMv2/Dkgxlpk72GTc2sia/3/6Q=",
      "url": "assets/images/distribs/distrib-03.svg"
    },
    {
      "hash": "sha256-UjhCF0NSI/j7aO+O4J+jabORpGrVinQhL2P86b3HVxw=",
      "url": "assets/images/distribs/distrib-04.svg"
    },
    {
      "hash": "sha256-WNVVx2HlJvS7iTzo7EqsoeFRjE4iwieteaW7UBoi2Cc=",
      "url": "assets/images/distribs/images.json"
    },
    {
      "hash": "sha256-ripCWuXG7SdEyCPLDb8n/mI44TS8Jgrel135pZOWBas=",
      "url": "assets/images/etc/book-thumb-default.svg"
    },
    {
      "hash": "sha256-EHfS8Wos90UcZL+AD01ZzwPkOLeVoU8qU/2GL4CPPJg=",
      "url": "assets/images/etc/distor-default.svg"
    },
    {
      "hash": "sha256-PImGqikJxlX0ZxuSwCuJVdNpDSZ+saqUKCFIpGHs2K4=",
      "url": "assets/images/etc/library.svg"
    },
    {
      "hash": "sha256-hseWS5G8q3EBfWV3GxmBmlxadHD1zhbhB6j56nXN/ms=",
      "url": "assets/images/faces/face_01.png"
    },
    {
      "hash": "sha256-4bfizFTx+t7ECOr9ne2uCEEZIWIPWS4JpnRbDTcaSTo=",
      "url": "assets/images/faces/face_02.png"
    },
    {
      "hash": "sha256-nZWK97ecD0W+vLaqc5t8WktQiPB1NL6BA3/HYCl0+Fc=",
      "url": "assets/images/faces/face_03.png"
    },
    {
      "hash": "sha256-84oCqtI2OiFPAuNhd6lGVplRwICubl3OoWkumOvLli8=",
      "url": "assets/images/faces/face_04.png"
    },
    {
      "hash": "sha256-z0Mneda1b3WkRldBitEOVuu8enEbQtf2trfYcJDsY6Y=",
      "url": "assets/images/faces/face_05.png"
    },
    {
      "hash": "sha256-1bM8BfQEVSMg+3WPM/jMl7x5G1Jr9OJyKqOp/GnKIqw=",
      "url": "assets/images/faces/face_06.png"
    },
    {
      "hash": "sha256-3QmgPXwxBPctvb0M5FjuVC1pq4L+CfGN3fiP1l5MW+0=",
      "url": "assets/images/faces/face_07.png"
    },
    {
      "hash": "sha256-5AuL/cqS73Ygm7rgj42JwewoiG0bv7RFHm4kWEBFVfA=",
      "url": "assets/images/faces/face_08.png"
    },
    {
      "hash": "sha256-En7VUgbEWVy8kiYdG9GhfxJ06Wvg3gEAqD86QvDUczc=",
      "url": "assets/images/faces/face_09.png"
    },
    {
      "hash": "sha256-czLrOGYA7CVWKiLbDFADmbL6ct3VZ/bu1UjFDDz1Wjs=",
      "url": "assets/images/faces/face_10.png"
    },
    {
      "hash": "sha256-0zumCQEieiYCmSyub05e/uNFSJo4McaYqQNm+11hmHU=",
      "url": "assets/images/faces/face_11.png"
    },
    {
      "hash": "sha256-urWy9Sh3jJZwghAOAh6OdUHNuungGDHfVNpxW2yfdw0=",
      "url": "assets/images/faces/user.svg"
    },
    {
      "hash": "sha256-Rb2A3aObZLKYTt4ezZJBLJuU4nmKM3Xblpt7DfD5VRw=",
      "url": "assets/images/faces/userfaces.json"
    },
    {
      "hash": "sha256-5XYmcI8SsCdWOp3MldCwGbg5HrkVTLcMp8Zb1Oqa3OI=",
      "url": "assets/images/flags/ac.svg"
    },
    {
      "hash": "sha256-ugrr47IngdWvMBURdVKDdB0Xt7aapIW19ctQdpiifII=",
      "url": "assets/images/flags/ad.svg"
    },
    {
      "hash": "sha256-hYVqJMuKcRE3iKJaUYDTNBbJePH34IOJolcXOd8OYpw=",
      "url": "assets/images/flags/ae.svg"
    },
    {
      "hash": "sha256-aUK2aDWAEHUER4VJLX8B5spK2FIVzVP4cmqmjzfwBkc=",
      "url": "assets/images/flags/af.svg"
    },
    {
      "hash": "sha256-AgjkD1VOMnzguGpf6WbsozcRE2a/tR1+Ysnoqz0JJhU=",
      "url": "assets/images/flags/ag.svg"
    },
    {
      "hash": "sha256-SS0/r4/0VnIPApIEx9QZ+IMMDPxgCyWPOunvwQ/MfbI=",
      "url": "assets/images/flags/ai.svg"
    },
    {
      "hash": "sha256-MqTdupgoN9JP1stCbqAlK3naVYE+AHx/4MQ+L2QWD2o=",
      "url": "assets/images/flags/al.svg"
    },
    {
      "hash": "sha256-8BotceMq9VzAKzXAiZ2G+KBOPGW/NH26lRSMRm0U884=",
      "url": "assets/images/flags/am.svg"
    },
    {
      "hash": "sha256-P72Mk50KIy/GXC1GMfk9VMmXtH/Sw9BnJNpxYuctdmU=",
      "url": "assets/images/flags/ao.svg"
    },
    {
      "hash": "sha256-OjOLqXxawDgvUbErXF05teE7bMWT4+12TGEV/LKnNEA=",
      "url": "assets/images/flags/aq.svg"
    },
    {
      "hash": "sha256-pIEsX2iIoWfAvxvGVbedbrDimS4btnmdVNvx9FELwU0=",
      "url": "assets/images/flags/ar.svg"
    },
    {
      "hash": "sha256-ZXx7/jAMcYkHPQogYMdDD6ziyTaIoiHrc4ygrEb6Jds=",
      "url": "assets/images/flags/as.svg"
    },
    {
      "hash": "sha256-9o20XuQ3zm9Cdjlnp5NUk/rpqiUqnFLO3Xz+wxGx+Pw=",
      "url": "assets/images/flags/at.svg"
    },
    {
      "hash": "sha256-rmDGJXVkgR18grHa5pQ9OgKp5xzus63b5TmHoNPfvKQ=",
      "url": "assets/images/flags/au.svg"
    },
    {
      "hash": "sha256-+O5+v2Ru1w3MfXx3UYWn1RXZqZMlH3zp1L/1hdJgIh0=",
      "url": "assets/images/flags/aw.svg"
    },
    {
      "hash": "sha256-BLv9z0RyIhPvBEfkiy0LkIJNgfEWx6KYNQz6j00pb30=",
      "url": "assets/images/flags/ax.svg"
    },
    {
      "hash": "sha256-lEp48OwaurJL5qneYl3Py8UQ9wtePFzBod8I/EnbJ9s=",
      "url": "assets/images/flags/az.svg"
    },
    {
      "hash": "sha256-uC/ECRlGzwM6vqxZUVtM1SF/XB7jijV4Sbkq+6oC9xM=",
      "url": "assets/images/flags/ba.svg"
    },
    {
      "hash": "sha256-F0o3gh0gx3NVdxJx0InSSmIFuSO5RkgmNC17J4foJ50=",
      "url": "assets/images/flags/bb.svg"
    },
    {
      "hash": "sha256-V//Ow4o7MG6ACGdLti4kfKuFW/nZ5Se5pQRpHSpqaI4=",
      "url": "assets/images/flags/bd.svg"
    },
    {
      "hash": "sha256-6jcgNRZ+5Nx3JTw1g2nZW4lTnyllzz3KcpPuayj1OgE=",
      "url": "assets/images/flags/be.svg"
    },
    {
      "hash": "sha256-aZFj5vHJb7O11C1nJS2jUBUv+kxZjzR2L+reZu3hWWg=",
      "url": "assets/images/flags/bf.svg"
    },
    {
      "hash": "sha256-0WG1piNlCi62NLzLBJDp/T7iDS/0ttMd+KM1/nEBtus=",
      "url": "assets/images/flags/bg.svg"
    },
    {
      "hash": "sha256-HLdyVpkL5JhVkED4Zp5FLolvPtmVV3FfBM/o9V+iTLA=",
      "url": "assets/images/flags/bh.svg"
    },
    {
      "hash": "sha256-oehiTzZBo6v3lCN10mGlXMpsm/v6DrpNLSnCTi2Yaag=",
      "url": "assets/images/flags/bi.svg"
    },
    {
      "hash": "sha256-3jQgIDHvJ0fvDGl1zYGF21q4DMZ54ZMv8kiZSoRZEfo=",
      "url": "assets/images/flags/bj.svg"
    },
    {
      "hash": "sha256-Vlc8bd7RhAurbpjv2cIMyeyOKRYtz/o3nZUnfaYab3E=",
      "url": "assets/images/flags/bl.svg"
    },
    {
      "hash": "sha256-kSlGXaNMgxXAmLOCyruDQ/Wx7znULT8vbt1xYjliDuw=",
      "url": "assets/images/flags/bm.svg"
    },
    {
      "hash": "sha256-czVlmhhRQ0Z6VKhDP5KURtZ3t03w7dQ2N8MUVHASNB0=",
      "url": "assets/images/flags/bn.svg"
    },
    {
      "hash": "sha256-YrmbX8tR0Enahr/Kch4JXZO6Bb7CBepvniIfRRU3ldk=",
      "url": "assets/images/flags/bo.svg"
    },
    {
      "hash": "sha256-82zy4KPfX/3oaKoLa7qjzD7Fl10eS5R14UYpnxnpCJw=",
      "url": "assets/images/flags/bq.svg"
    },
    {
      "hash": "sha256-Lr9t0ftsh7vXew/AI8fDq8v6t30fl8Kbj8H+Cgo5jaQ=",
      "url": "assets/images/flags/br.svg"
    },
    {
      "hash": "sha256-auYvbuYZXcw/isP43Q1J5R3fJnXya+ycn1316pqrBAY=",
      "url": "assets/images/flags/bs.svg"
    },
    {
      "hash": "sha256-7rRbdnLPIeN0MTFM0GLvi6Vn2Svtj0LJfyU9kkbr9DM=",
      "url": "assets/images/flags/bt.svg"
    },
    {
      "hash": "sha256-OtM85LC4aB+Wa1HV0RYzU5XYfFRxN90ltne1trJVXrc=",
      "url": "assets/images/flags/bv.svg"
    },
    {
      "hash": "sha256-l/unBJ0kmAJ6bUV1/+kzVhe9JmomBr74WsMlTiq63+E=",
      "url": "assets/images/flags/bw.svg"
    },
    {
      "hash": "sha256-/Qq15fP1obV9K4HaHkValUPEeZBANFEtjcJZLi7BoVI=",
      "url": "assets/images/flags/by.svg"
    },
    {
      "hash": "sha256-BTMg6YPZwkjQ3iICPkpbyTtbn1eXAz6SweqnB+2vfaY=",
      "url": "assets/images/flags/bz.svg"
    },
    {
      "hash": "sha256-BBQPIHajkx+QCBgLww3jNM5HuVL47BM3Fg+kPbohAEo=",
      "url": "assets/images/flags/ca.svg"
    },
    {
      "hash": "sha256-AwBkl/7Ni00RK2pNzDA4xFUhQKO0XaGhdEUMLFweAEU=",
      "url": "assets/images/flags/cc.svg"
    },
    {
      "hash": "sha256-TWBjc8Qr72S8+qkAJn3/Qw7GSqjzLcIu7t7AVhNB5+A=",
      "url": "assets/images/flags/cd.svg"
    },
    {
      "hash": "sha256-0O1PW9XFVr5HgohQoXkTXYYweKccGRInJvzCTGNK0qQ=",
      "url": "assets/images/flags/cf.svg"
    },
    {
      "hash": "sha256-9N/vbId7aChAx4O4/oBghHANCdiCQ47hsGPy2mYkUgA=",
      "url": "assets/images/flags/cg.svg"
    },
    {
      "hash": "sha256-7/uuJ2wcztr+kZgBnFfdeYXnBXaGmKyyfWmC29h5dVA=",
      "url": "assets/images/flags/ch.svg"
    },
    {
      "hash": "sha256-rZOjsZDeaosFQ+H6fb/2uJ8iDT0t4/oWYiocJ8ScUO0=",
      "url": "assets/images/flags/ci.svg"
    },
    {
      "hash": "sha256-jg4zePAJmViqfeqMjgt+1HNcjHo+p9SwzW/EjHUrQNw=",
      "url": "assets/images/flags/ck.svg"
    },
    {
      "hash": "sha256-PfX5tYSL0DYH63cfnl16e5XReT4LTM+OmGMk6le/GCA=",
      "url": "assets/images/flags/cl.svg"
    },
    {
      "hash": "sha256-ajb27sEAyIxxYqen1QbY/h8CL2LvPt6U+GP44WgIw+4=",
      "url": "assets/images/flags/cm.svg"
    },
    {
      "hash": "sha256-UFZ1Kkau43QkfEzPSfEirwQefHydEPb6hDy2bujb4fY=",
      "url": "assets/images/flags/cn.svg"
    },
    {
      "hash": "sha256-C3OvZ8p40qDySnSAecwYxuGgTIsFBsJdlq/w5o3xV9I=",
      "url": "assets/images/flags/co.svg"
    },
    {
      "hash": "sha256-q8nFewjQWlIbf0LoEjJqFH3BynaIQJtKmqZxH7Zm8S0=",
      "url": "assets/images/flags/cp.svg"
    },
    {
      "hash": "sha256-LoR/zOonp9uru4JpSAm6fuZZwZeI2yxignHcadhvd+w=",
      "url": "assets/images/flags/cr.svg"
    },
    {
      "hash": "sha256-AAjE1OKZz3aqE9fYGx5wCVPSiQZwW0RF3/zN11PCQog=",
      "url": "assets/images/flags/cu.svg"
    },
    {
      "hash": "sha256-fGGQuPZ08iH9RGmTRRFsWksH3GkDsd07zAhVsvh2+6Y=",
      "url": "assets/images/flags/cv.svg"
    },
    {
      "hash": "sha256-x+H4aM12x+PB1oKbMdSKNKAoAmu/7AMgoYmYGygiRcU=",
      "url": "assets/images/flags/cw.svg"
    },
    {
      "hash": "sha256-q7YzDfCsS4+3ioTJipPzvyXCzA3jvT5IuXycgLCsdKo=",
      "url": "assets/images/flags/cx.svg"
    },
    {
      "hash": "sha256-UW0+CR4Ey2VtmmfybYWN+K8xgN/fR8SM49bA201Q7hk=",
      "url": "assets/images/flags/cy.svg"
    },
    {
      "hash": "sha256-X5T5Ws8u+fkKBVlNHpY3PZ3YTINCFO15pkrHL/XEgEY=",
      "url": "assets/images/flags/cz.svg"
    },
    {
      "hash": "sha256-6g3YtZX/l4jY9VnGCa18tfqKAwUz0ZRsz8RsXgvnSbM=",
      "url": "assets/images/flags/de.svg"
    },
    {
      "hash": "sha256-7ErdUkhHbN+Cc/IK4z4I7w3VTlwhVDRaLejNcpM4m6E=",
      "url": "assets/images/flags/dg.svg"
    },
    {
      "hash": "sha256-SnwZZzLF1Zg5YZdSUBmr+fRlK5v8oJO4kBAKriy4DZc=",
      "url": "assets/images/flags/dj.svg"
    },
    {
      "hash": "sha256-7fQkorZefREItm902a3mrSQNvcftArNVw89kUMa0pQY=",
      "url": "assets/images/flags/dk.svg"
    },
    {
      "hash": "sha256-eOE9M9hbT8LwMRU4773opPcMMLFeKEXkTRlAe/a7+o0=",
      "url": "assets/images/flags/dm.svg"
    },
    {
      "hash": "sha256-xiejCUN6i1TgpEG2cS2HCiNMmSdVmqC/XH4rAf3G/y0=",
      "url": "assets/images/flags/do.svg"
    },
    {
      "hash": "sha256-j2mLXA+h4MEOiMjQMYrqJYgFcBfqb1TVQURbRqdLhKg=",
      "url": "assets/images/flags/dz.svg"
    },
    {
      "hash": "sha256-hwmQevLxV622+WECH0yLVoi2ln3znOpFUAGjZnqVjcI=",
      "url": "assets/images/flags/ea.svg"
    },
    {
      "hash": "sha256-ayBCK8KFZEfYF/Os52aldjuZkNLIBA2EOuCzuRGQx68=",
      "url": "assets/images/flags/ec.svg"
    },
    {
      "hash": "sha256-nPNTCl1yZD51nu1Yw1y+FC0SGKqqJR8m8Eme9lDO2kU=",
      "url": "assets/images/flags/ee.svg"
    },
    {
      "hash": "sha256-zpgYWO7ZvCvNUMY02yTzVi/I8SQxKKNpCJMv7c/zZAA=",
      "url": "assets/images/flags/eg.svg"
    },
    {
      "hash": "sha256-ewJTleyaqMhX35LiLBcMHuBquNNzrIzk5f7ihYBd5vQ=",
      "url": "assets/images/flags/eh.svg"
    },
    {
      "hash": "sha256-n+2Tbu2+veuuTkO3rKJyffvu6sznrha2L4XWvb+4sgs=",
      "url": "assets/images/flags/er.svg"
    },
    {
      "hash": "sha256-K4tjY+ccCYElTcSbu21dZXAN9ccJkTYkXh1Y88ScXt0=",
      "url": "assets/images/flags/es-ct.svg"
    },
    {
      "hash": "sha256-xUxmS72LSqsCfu/tuhyb/fvX+Shrj1fTNHCoFjIe4yo=",
      "url": "assets/images/flags/es-ga.svg"
    },
    {
      "hash": "sha256-mRQgBC2lHbJ448fcA0sFZvuf2I0b3PfxnHkYH6eqxYs=",
      "url": "assets/images/flags/es.svg"
    },
    {
      "hash": "sha256-4UkQveBXO1cDZwnTHXuskk7XUEcq6Z00nGntwvgJhVQ=",
      "url": "assets/images/flags/et.svg"
    },
    {
      "hash": "sha256-YQldtr+DQopo2ECnH8BUOU39o8nvns2C2SJg1YNtZmo=",
      "url": "assets/images/flags/eu.svg"
    },
    {
      "hash": "sha256-fdAT8H+e++fz6vMX3t1C0f/6lXHkezFG43c1i9jBzR8=",
      "url": "assets/images/flags/fi.svg"
    },
    {
      "hash": "sha256-A2EOcAqB89c0otLaCyqHbgD9QlltVH8NdPRvQoMquTs=",
      "url": "assets/images/flags/fj.svg"
    },
    {
      "hash": "sha256-swInvF8JEP1EhErQ++JPIHt3mRRLri3WUtmHCHS2+Gg=",
      "url": "assets/images/flags/fk.svg"
    },
    {
      "hash": "sha256-rXqBk8gOLBccboxSt4dpiaDXpidqpwdtLYkrOJvVtTo=",
      "url": "assets/images/flags/fm.svg"
    },
    {
      "hash": "sha256-WwvvQWaFY+LyzgOPFOg8swhJokStjwxi+IErOyqSzNM=",
      "url": "assets/images/flags/fo.svg"
    },
    {
      "hash": "sha256-aic97/D5OPUSdIXDtVLOGM7JzehMktXkEX2mV0oQ798=",
      "url": "assets/images/flags/fr.svg"
    },
    {
      "hash": "sha256-rUD/jt6xIFDR/JIIMtXxo+etiP2ospbkF6Ut+GhqQzI=",
      "url": "assets/images/flags/ga.svg"
    },
    {
      "hash": "sha256-STx+C1liQTpIGJfQfsN1uZQJW1306ceJpWvyVQ44Mn8=",
      "url": "assets/images/flags/gb-eng.svg"
    },
    {
      "hash": "sha256-NjLyR+CvlkEFyAHivuttfP7JDXmd5ynKnRnlsUOGXLQ=",
      "url": "assets/images/flags/gb-nir.svg"
    },
    {
      "hash": "sha256-BNZFbbyyZwfuBF4Nt/lbDykNbeZVZ1fVaIO9+CljhCM=",
      "url": "assets/images/flags/gb-sct.svg"
    },
    {
      "hash": "sha256-CwUZRqXTKnlI1ma8FWCnOM5K4LZInf8hURG54YDZsls=",
      "url": "assets/images/flags/gb-wls.svg"
    },
    {
      "hash": "sha256-OR02PeC9zazhOsr0b3BQAbP4nT3t5P8YqMt/wgL+yEQ=",
      "url": "assets/images/flags/gb.svg"
    },
    {
      "hash": "sha256-TIIMhLGbPnTLox3uYaJjvSKT0DCo0IaGjDQRpvA0xXY=",
      "url": "assets/images/flags/gd.svg"
    },
    {
      "hash": "sha256-mvCTR1tDDFNTSG2UdxMGUoCwEf3781PQjuji5tCIDJY=",
      "url": "assets/images/flags/ge.svg"
    },
    {
      "hash": "sha256-OBtWwK96AsnOe4yrNKEeuNm+Qi4DJJ3Js+UGY0EwmSM=",
      "url": "assets/images/flags/gf.svg"
    },
    {
      "hash": "sha256-1s2Cpb6IXkOXcRLzsGazeVrU6Lf68ldupVmQM5/sNS8=",
      "url": "assets/images/flags/gg.svg"
    },
    {
      "hash": "sha256-Sbrujid4dxk/3hpiDH5DWvXwn8ZI424OqL7l4XCR48U=",
      "url": "assets/images/flags/gh.svg"
    },
    {
      "hash": "sha256-mpdpABlYDuwxk9MtkyybKBcprd+dWowKzzDXJyw36WU=",
      "url": "assets/images/flags/gi.svg"
    },
    {
      "hash": "sha256-Jkq6BRwDUJ5fAWlRejIdzWa8+kF58vo8O09fG3sOtmI=",
      "url": "assets/images/flags/gl.svg"
    },
    {
      "hash": "sha256-3r5iyXSVfcikuVsjxnTs7Pnkdvu5WgHRpYmfbeAK6TY=",
      "url": "assets/images/flags/gm.svg"
    },
    {
      "hash": "sha256-fogvu5FWXkKZyf+dTHSoxuPayb1PJiL953WG6bAkIaA=",
      "url": "assets/images/flags/gn.svg"
    },
    {
      "hash": "sha256-z3G+0I/qDjjr2aKTFeppBtiOwedgtl8IWzvZf+rp0Js=",
      "url": "assets/images/flags/gp.svg"
    },
    {
      "hash": "sha256-W+N4fAdODdx+82tQfrzPu1hTKvctueV++stuC2JPk9c=",
      "url": "assets/images/flags/gq.svg"
    },
    {
      "hash": "sha256-F65XjMQOugUYEoDSmVH0Ycq4IT0Vt3tgyabhb6bxm3M=",
      "url": "assets/images/flags/gr.svg"
    },
    {
      "hash": "sha256-NBwZNjVRAJYe5B6soIlRGUZyj9Xp+vh8CsktcB5RwQA=",
      "url": "assets/images/flags/gs.svg"
    },
    {
      "hash": "sha256-4I5tuQwuDRG3AsPmb14zv7Q682xdmELfviSkSK8I4L8=",
      "url": "assets/images/flags/gt.svg"
    },
    {
      "hash": "sha256-br62Pt1LVHcJ2wNTcQsobOah2FpyyGQFmvJCtN0Jj5w=",
      "url": "assets/images/flags/gu.svg"
    },
    {
      "hash": "sha256-FO8qvLZHBSJxds9wVWnzsKM4U9cC6DPURVMvgKlS5GQ=",
      "url": "assets/images/flags/gw.svg"
    },
    {
      "hash": "sha256-6/ayrvN7NiAvpTjnyWy4PCiXu+euAX9Q9JAwjJk4zE4=",
      "url": "assets/images/flags/gy.svg"
    },
    {
      "hash": "sha256-8toOTbJj4VZHTqgR0oj2MC/2ZW0adQPOyWFX9k0Xrko=",
      "url": "assets/images/flags/hk.svg"
    },
    {
      "hash": "sha256-QaPHivNWsP4eIGikfjEazgJyGNgeK84kjK6p7qd7xes=",
      "url": "assets/images/flags/hm.svg"
    },
    {
      "hash": "sha256-fKUnAF5lk9+4fEEJinOCCzpzG3fX/J9xR6jx1owYV+8=",
      "url": "assets/images/flags/hn.svg"
    },
    {
      "hash": "sha256-hsHBGWzvyaIG4BakFIZs3AF5GO+4R10JI95FHEon26w=",
      "url": "assets/images/flags/hr.svg"
    },
    {
      "hash": "sha256-8TWWtgmzWXqen5yfpbIeCdDs/UJxTi/8uX9xljwP0HY=",
      "url": "assets/images/flags/ht.svg"
    },
    {
      "hash": "sha256-hbKheYa7ax30iTfN6T4aLQFnAAKebefrm0Ov5m672jY=",
      "url": "assets/images/flags/hu.svg"
    },
    {
      "hash": "sha256-6VT56Qx7BTvSw3QXFAKtZdAViIc8NOOhUzgiiesCwEo=",
      "url": "assets/images/flags/ic.svg"
    },
    {
      "hash": "sha256-HJ+PZ4afCPu1zmjL5veFGvEjoEbjgn/JBHu9S+Gcdww=",
      "url": "assets/images/flags/id.svg"
    },
    {
      "hash": "sha256-0ryJDfez06pepqdZFvdXY9gpA18fbQECUu0yaYw9pNg=",
      "url": "assets/images/flags/ie.svg"
    },
    {
      "hash": "sha256-ukUHg9pIQ0HtKAEmA8qOHKGCEkInnZj9t9BumNWPBf4=",
      "url": "assets/images/flags/il.svg"
    },
    {
      "hash": "sha256-d5p3LkffvaeJ/XEDyZ9pbRAlFDkSQ2RdYmDUP34Xze4=",
      "url": "assets/images/flags/im.svg"
    },
    {
      "hash": "sha256-+EkJ6P15dh7xnmuH5IAaxPh5v5gnJF7I87LLgBAbW1g=",
      "url": "assets/images/flags/in.svg"
    },
    {
      "hash": "sha256-7ErdUkhHbN+Cc/IK4z4I7w3VTlwhVDRaLejNcpM4m6E=",
      "url": "assets/images/flags/io.svg"
    },
    {
      "hash": "sha256-IMgQHmt0FFUQNM3keitaGZxzw0XmtN0Q1cTOphfWEtc=",
      "url": "assets/images/flags/iq.svg"
    },
    {
      "hash": "sha256-NmnEOvZ0AcqGEYAj+oMJrSHrzHKXax3axDtnSaP32l4=",
      "url": "assets/images/flags/ir.svg"
    },
    {
      "hash": "sha256-yKrcWmpnLIGAdFwTC9wMRG7Yf93pAM3kWrjPVUUMS6Y=",
      "url": "assets/images/flags/is.svg"
    },
    {
      "hash": "sha256-8kKjgDath8n7x9sbkBu8Jz2gwQgS94NIWGK84/pUepc=",
      "url": "assets/images/flags/it.svg"
    },
    {
      "hash": "sha256-6828HDVhCKS4t337SrRKWl2jW38cI/+nf5omgtQVj3E=",
      "url": "assets/images/flags/je.svg"
    },
    {
      "hash": "sha256-1pRTDoL6UXrtzVB5941d2cw2ZtX76A0fgrK26vG5GA8=",
      "url": "assets/images/flags/jm.svg"
    },
    {
      "hash": "sha256-tvN5SOcWMI68tinJMuj4HJ3WNajiAujSl9PHzMpdLg4=",
      "url": "assets/images/flags/jo.svg"
    },
    {
      "hash": "sha256-KvzwLaDpsWpFpHIqNtzVDyHLX9isLaZ7xUwbHt8X7Dc=",
      "url": "assets/images/flags/jp.svg"
    },
    {
      "hash": "sha256-pJMQZ5eYNWikMHWwiuZ4JT3wbAkaxK2H3keF66ev3yI=",
      "url": "assets/images/flags/ke.svg"
    },
    {
      "hash": "sha256-ocDfFf+sHL3WVBPA4jv/UiSuQjxJA1jCODbQH1f0Q2I=",
      "url": "assets/images/flags/kg.svg"
    },
    {
      "hash": "sha256-htZ+KDAkz+2V/ekxibJlIlK0ssdczBHs6/gPLaiSsaQ=",
      "url": "assets/images/flags/kh.svg"
    },
    {
      "hash": "sha256-4/yz8d7UhoYDdd0Z1pOxdPaRMEmNtXsWonnigsRbSOs=",
      "url": "assets/images/flags/ki.svg"
    },
    {
      "hash": "sha256-OA4GeMzwhDSgpK+jBnyjeuKCb+l/p0BQ869O9rDg7q0=",
      "url": "assets/images/flags/km.svg"
    },
    {
      "hash": "sha256-5r3FYEP5rzzkEGiTqTDW6BIYEhE7DYzWjG0OjuaB3FQ=",
      "url": "assets/images/flags/kn.svg"
    },
    {
      "hash": "sha256-lJu/HZWWcvhWQZw7fmUHD98w01J3hrJxtMUiuvbci38=",
      "url": "assets/images/flags/kp.svg"
    },
    {
      "hash": "sha256-wTTrURBJinx0PcVJYh0VfKkItcrfhwFO6b/hqPVOgEo=",
      "url": "assets/images/flags/kr.svg"
    },
    {
      "hash": "sha256-3O5OqpIX0WE/6xh5aruHoA8ackISJn0XKd1s/CWeau8=",
      "url": "assets/images/flags/kw.svg"
    },
    {
      "hash": "sha256-3uWfqPAV1VtbEXXLo3ttye+W2UOHadt91rRC17j7SUc=",
      "url": "assets/images/flags/ky.svg"
    },
    {
      "hash": "sha256-b/NZs3jBvN1T0GxyPApEzEEFrtx4kiV7czg2P2jv4JU=",
      "url": "assets/images/flags/kz.svg"
    },
    {
      "hash": "sha256-LKNIanGnn2xrfCUMcB632I5BaUa/ZOnwx0ruIk/HikQ=",
      "url": "assets/images/flags/la.svg"
    },
    {
      "hash": "sha256-5PjpepuBgOOqST0q1CV0KLGQpl3218e6CaH9/FwcjQk=",
      "url": "assets/images/flags/lb.svg"
    },
    {
      "hash": "sha256-4EGzES+N+TWSX8+UXGFptUhWZW2hspKlIttK4ZG7zto=",
      "url": "assets/images/flags/lc.svg"
    },
    {
      "hash": "sha256-wu2mNjG1JIMIZkGvwK6mf1XTYmq5qUAMSZY+l50DbdM=",
      "url": "assets/images/flags/li.svg"
    },
    {
      "hash": "sha256-N8n2qGvw5O7+N9hzdk/4q83TDsvHBHnLg1nce3KGgn0=",
      "url": "assets/images/flags/lk.svg"
    },
    {
      "hash": "sha256-O5ueUZIpMv3UGtgkf7PpAnh0S8/tpPTt1ZG0/oBDUcU=",
      "url": "assets/images/flags/lr.svg"
    },
    {
      "hash": "sha256-ttEK6pOTAfol/LlEnRpGvc3rglDhl+a9N2mvGy3TCVM=",
      "url": "assets/images/flags/ls.svg"
    },
    {
      "hash": "sha256-lCaJOgBKWGEGHsRZEI02PwAy5IYb85hzIUJ2NZ0vZ6o=",
      "url": "assets/images/flags/lt.svg"
    },
    {
      "hash": "sha256-go3xin/Pe+vSg1UnTZUVzxaLPF0ik2/+rb0u0s4Uu58=",
      "url": "assets/images/flags/lu.svg"
    },
    {
      "hash": "sha256-8d4OcFtGEW/b5QMBiYQINsdt+lt7SPgBDV7StVe9RiU=",
      "url": "assets/images/flags/lv.svg"
    },
    {
      "hash": "sha256-r1rI9buOrmXL90a24pGHyny02MxxxBlWKd4QBdI5QK4=",
      "url": "assets/images/flags/ly.svg"
    },
    {
      "hash": "sha256-FNwoljTKneqU/5fMPgexhzyCAPrVY2OYBFnIZgMvGD4=",
      "url": "assets/images/flags/ma.svg"
    },
    {
      "hash": "sha256-IMWBoPcp8d7qo1b+9J6UXxuDf6INhLr0Gop+o/pC+g4=",
      "url": "assets/images/flags/mc.svg"
    },
    {
      "hash": "sha256-Kx3FjxVEhpWJ7sSETLkRDG+J9SjvzYAYaPqt2kKItdQ=",
      "url": "assets/images/flags/md.svg"
    },
    {
      "hash": "sha256-Ivj+S5dQbFQchK7tBkC/T0NTQwfoOqOpU+l0MOCX2zc=",
      "url": "assets/images/flags/me.svg"
    },
    {
      "hash": "sha256-J4oS/YeSVqDaWES8OW9VjtYqVJu41BN61R0yc+pNvZs=",
      "url": "assets/images/flags/mf.svg"
    },
    {
      "hash": "sha256-Ba6pytYTQYpQHU8Tp5tTJsRkexfToD7bGQaZ3ph4sEo=",
      "url": "assets/images/flags/mg.svg"
    },
    {
      "hash": "sha256-Kvg5IeAoqmR3+ShsuCaTaZR3sYS5mRwVklze5/30O74=",
      "url": "assets/images/flags/mh.svg"
    },
    {
      "hash": "sha256-EDpxzsCI8C6iJuEciFCmQwyELywruRItOI/WUVLgQ8I=",
      "url": "assets/images/flags/mk.svg"
    },
    {
      "hash": "sha256-9X7ogFAvbMI2uOodn4mp+TOyS9Uwt4S4wQlo43FPPKk=",
      "url": "assets/images/flags/ml.svg"
    },
    {
      "hash": "sha256-cV1h1WrKPsTR9VEYW4BwAi7ftsbB2eMon5WxN6nv+e0=",
      "url": "assets/images/flags/mm.svg"
    },
    {
      "hash": "sha256-M1oKAwaHwCOnSMXFAYMjMb+efskmYXhQDFbtTNnqAkk=",
      "url": "assets/images/flags/mn.svg"
    },
    {
      "hash": "sha256-vyOfUmu+yGAuJaKlZcClbfiwx5M7v6uS7skd9j0vhtU=",
      "url": "assets/images/flags/mo.svg"
    },
    {
      "hash": "sha256-9P4hUP3t6kOERAJF/uA35bF8rYaP+arXweNiVYkMccI=",
      "url": "assets/images/flags/mp.svg"
    },
    {
      "hash": "sha256-KmrMfoSeBlLTg2SQUHUctIbgIdN8iH8BOnJX9ms7xLQ=",
      "url": "assets/images/flags/mq.svg"
    },
    {
      "hash": "sha256-d/KQ/ZID1z21eDXfTSN0Wq8IsvrhXS85hUBA4z6xgRs=",
      "url": "assets/images/flags/mr.svg"
    },
    {
      "hash": "sha256-2dsIzvMqaiEf9d8hDbHBn33dxVUwLq2ECkcy5SPxFQE=",
      "url": "assets/images/flags/ms.svg"
    },
    {
      "hash": "sha256-ax2LebxER32n5AFwNGZo/qZ2aZaz/3YHvG4e8kKQA6M=",
      "url": "assets/images/flags/mt.svg"
    },
    {
      "hash": "sha256-bTNYBUQq0rHfWYCvhXdAM0u1dBrTDiRxkLP+plwYsOk=",
      "url": "assets/images/flags/mu.svg"
    },
    {
      "hash": "sha256-evou14AK+lkHfyzUo7bbPKRmSez+xAIMkL98SrUiz78=",
      "url": "assets/images/flags/mv.svg"
    },
    {
      "hash": "sha256-wXRWXRnCt0ceelq3Ra60DPUXe7eNA2AQxKskEYOnF1c=",
      "url": "assets/images/flags/mw.svg"
    },
    {
      "hash": "sha256-1//XPOpPUt4z3CDxIgbi61koR6fhWYjd6cuIMRQj3hU=",
      "url": "assets/images/flags/mx.svg"
    },
    {
      "hash": "sha256-NyduX7XNagKZ1NgBFW7ZGO5cF9Qa1wasVu25GNQX5oI=",
      "url": "assets/images/flags/my.svg"
    },
    {
      "hash": "sha256-NoJ5Dz5GYuj7dd3W51UdworosVFi0TdFr19pHy5Dmvw=",
      "url": "assets/images/flags/mz.svg"
    },
    {
      "hash": "sha256-09UYFa8Hgw4gHdoHpqKeYvM97OMPrKMZAXPemsOrulI=",
      "url": "assets/images/flags/na.svg"
    },
    {
      "hash": "sha256-Xc+0E7UB0stxc5bsykz/yEuwGVm5AZf8Y1112h7XeAU=",
      "url": "assets/images/flags/nc.svg"
    },
    {
      "hash": "sha256-21Y7SmF/bSwTTq8hVCZLcD9X6xhIDVutCPf6fQTF7Gw=",
      "url": "assets/images/flags/ne.svg"
    },
    {
      "hash": "sha256-dWYqwMogQDpIGP+IbqPjaWe5nAWnK7zWR/hDznsaitw=",
      "url": "assets/images/flags/nf.svg"
    },
    {
      "hash": "sha256-tq3JlCNSXy8tRyT/cgeKNU+rZ2VYQTDpH5FJBneOgJc=",
      "url": "assets/images/flags/ng.svg"
    },
    {
      "hash": "sha256-3Qfs9UY7AfkaBBNYdOzBfxQ2VuoYxt/vwDR9Jkxy02g=",
      "url": "assets/images/flags/ni.svg"
    },
    {
      "hash": "sha256-mKtHzG+Cp9K/tnLDo69eeNB1PtZbJStuWSZoT4L4dzQ=",
      "url": "assets/images/flags/nl.svg"
    },
    {
      "hash": "sha256-hCUSpQo35MNdIlcZZ4+/rjGCjMWCJbmn5B4jmP7CBEc=",
      "url": "assets/images/flags/no.svg"
    },
    {
      "hash": "sha256-wDQgMgzkVzB1dTH2WKd7h4CyI8jKtUasfdxNZDllZ+8=",
      "url": "assets/images/flags/np.svg"
    },
    {
      "hash": "sha256-rasQG7vkbdbIvcBSgWs7jazEKDcd9OIpmPT1Yj78lwk=",
      "url": "assets/images/flags/nr.svg"
    },
    {
      "hash": "sha256-xMZLJmiV9FETU51AbaiF9v05g0uEPpMNvaHd34Ne2tM=",
      "url": "assets/images/flags/nu.svg"
    },
    {
      "hash": "sha256-/+sboVx4iQwj6A4XVKidWo/PHO3Kc4wyHCTMFwaQFHs=",
      "url": "assets/images/flags/nz.svg"
    },
    {
      "hash": "sha256-EUr9xtX/rBPRAcimBzLBXXDB0GzSRzfaOVgPQMA+dMg=",
      "url": "assets/images/flags/om.svg"
    },
    {
      "hash": "sha256-CzGf/EpRFHtjTpbMw7sUNoaUYvtq8jx2icfOe8QgPgw=",
      "url": "assets/images/flags/pa.svg"
    },
    {
      "hash": "sha256-0eRsnFXP2PZrNHkNB2WNDLnqJyG/4ucILNxBB6dy3qY=",
      "url": "assets/images/flags/pe.svg"
    },
    {
      "hash": "sha256-FzC/1GVNVRskKrWJNbNoakUrVU1MIQOdD/98IGPo8Yg=",
      "url": "assets/images/flags/pf.svg"
    },
    {
      "hash": "sha256-ewoSWhzU/Zy6En8sQpHuraU9P+VDISVQmEWXQlp8aDE=",
      "url": "assets/images/flags/pg.svg"
    },
    {
      "hash": "sha256-AwhqlVMt0hv11iMdfF7M4cSNV3U0WxLKu9djLqKrD5A=",
      "url": "assets/images/flags/ph.svg"
    },
    {
      "hash": "sha256-+sSYGYl+pwpfkymoJDlqEznbeHhNVgZN/y4HHbrjVaE=",
      "url": "assets/images/flags/pk.svg"
    },
    {
      "hash": "sha256-M9bddYR4iKY07LKYffSKKHRziXVmKMMyQss1NHrqegY=",
      "url": "assets/images/flags/pl.svg"
    },
    {
      "hash": "sha256-d7oXiOL2HQHMZjJaTlM/SnW8Q7x+jce3E2LclzU/UDM=",
      "url": "assets/images/flags/pm.svg"
    },
    {
      "hash": "sha256-8F0JK6CRO+3jereSd4riwXRSEi3nhJnpi2ClmrmwTdM=",
      "url": "assets/images/flags/pn.svg"
    },
    {
      "hash": "sha256-Uk+a23tFLlFvX/NKuwYbGgTFXdct2tCXyV+ZEgmvPUY=",
      "url": "assets/images/flags/pr.svg"
    },
    {
      "hash": "sha256-7p/H6QVww9oo9Y+Y6g4lLwKs5NwOrzY0HESfMR9zPjE=",
      "url": "assets/images/flags/ps.svg"
    },
    {
      "hash": "sha256-+yzMsJCzMs9TtWjUsa1R+eq5xiBtaDECiw6EOmImX48=",
      "url": "assets/images/flags/pt.svg"
    },
    {
      "hash": "sha256-KTNxdt4eT+c+vXPiItC96QPdjhIMAm0C6QMP8CQ4Qdo=",
      "url": "assets/images/flags/pw.svg"
    },
    {
      "hash": "sha256-iBLtqDBQykvNmsmi1JNrEgrF9k7sHK0ojrgVbi9SC3g=",
      "url": "assets/images/flags/py.svg"
    },
    {
      "hash": "sha256-5PUpM//fh7kaU2vJw6Yq2CnzzND4WmZPbXrx4U94/rw=",
      "url": "assets/images/flags/qa.svg"
    },
    {
      "hash": "sha256-eJ9o84X49EczG0AhM31kGkU+t/10h4nBQRPvcAae380=",
      "url": "assets/images/flags/re.svg"
    },
    {
      "hash": "sha256-0AZ6qLmb84eOJrnXliukTL37Qgo0hXeGzyaB5iXvXiw=",
      "url": "assets/images/flags/ro.svg"
    },
    {
      "hash": "sha256-oHTTQNzt/V8a+YHZbQmCJ/AbiiCtfzAoLlR5xpMbGZs=",
      "url": "assets/images/flags/rs.svg"
    },
    {
      "hash": "sha256-UVE1NsY9e74NM0WUqYZJq8wGfYXaYE9tFfL+1dgyCKY=",
      "url": "assets/images/flags/ru.svg"
    },
    {
      "hash": "sha256-u31smamoiHe7u20uA8Qbcy8X7IBA8OdOO5aCSUwJ2j8=",
      "url": "assets/images/flags/rw.svg"
    },
    {
      "hash": "sha256-2Z5TsOQVX9/7oUqfLIP9MczS9Ko4djZWaH+xwfLiXQk=",
      "url": "assets/images/flags/sa.svg"
    },
    {
      "hash": "sha256-MMd0FT6IKMtpaLK4eW0D05ZVlwBodyVmifLve2DQcdw=",
      "url": "assets/images/flags/sb.svg"
    },
    {
      "hash": "sha256-RI1KdB99s2EoIu7Rk7AAqc3eewGhpf2X7AN/gDWtVIs=",
      "url": "assets/images/flags/sc.svg"
    },
    {
      "hash": "sha256-hkMP70tJ5cSqjCLLoez4O3amhjAsMXNoXPYp6mavllA=",
      "url": "assets/images/flags/sd.svg"
    },
    {
      "hash": "sha256-9m1oM8Ug6/H/e3GRFd4JUQZQp5hO0a7lpA0ve9862ZQ=",
      "url": "assets/images/flags/se.svg"
    },
    {
      "hash": "sha256-ZsTm+ybbQvyV47G+1Zxx0yVu5zotp1fW8S17+Qi+FbI=",
      "url": "assets/images/flags/sg.svg"
    },
    {
      "hash": "sha256-l/PXOl2F35iDcsdlwV5bI+hoxgKMJ5oG2nZytnnOWZc=",
      "url": "assets/images/flags/sh.svg"
    },
    {
      "hash": "sha256-qBAA9tx0G3664HtZHNx/ECPklXd3dFN1/TEKFxXVY0M=",
      "url": "assets/images/flags/si.svg"
    },
    {
      "hash": "sha256-K5DSomzWQf7NYfzwNxYB/na5yVExKbD3q6O1Ha0kVx4=",
      "url": "assets/images/flags/sj.svg"
    },
    {
      "hash": "sha256-xEry9f3mOGZgPoK6rEbeNuswgnoxTCxFEUfnr615xNE=",
      "url": "assets/images/flags/sk.svg"
    },
    {
      "hash": "sha256-YfXS6Bt8xj4GV0wsFkCpJm6jxWt7RZozGi9cPFvQjFU=",
      "url": "assets/images/flags/sl.svg"
    },
    {
      "hash": "sha256-8pI6KVL0SGPyekzduyR9vna4rwoP+iSAI+Wga5WYMdM=",
      "url": "assets/images/flags/sm.svg"
    },
    {
      "hash": "sha256-Dp9m4wnNOyytFY3uO3LRrOI8igGD+bkZevnUpdmQCBU=",
      "url": "assets/images/flags/sn.svg"
    },
    {
      "hash": "sha256-cyni8obH9doRZL9DYkQW+4FQBODn/r9Dl6vf4GdQSBc=",
      "url": "assets/images/flags/so.svg"
    },
    {
      "hash": "sha256-TGkh8PBBX8No9NHCsR+92/AEf5rbpUJpkDcBJmDDi+g=",
      "url": "assets/images/flags/sr.svg"
    },
    {
      "hash": "sha256-p1zFwvK8TUwhVRovcAG+jt1AqovIHRDuezbFbwFpKhI=",
      "url": "assets/images/flags/ss.svg"
    },
    {
      "hash": "sha256-iZF+Z/c5MTk1lCoym3Hs2u5cuf3dcMkXgbNAVjfuaks=",
      "url": "assets/images/flags/st.svg"
    },
    {
      "hash": "sha256-TuuohijPpzBakBH+Wt+am86/1tWrkWyQP9r3g4oRsGY=",
      "url": "assets/images/flags/sv.svg"
    },
    {
      "hash": "sha256-vCudh5wYYKdTPYqTL+Xfg8aF2htT1M6mAH6LHPjkzWk=",
      "url": "assets/images/flags/sx.svg"
    },
    {
      "hash": "sha256-7lGx7kVX/I9NI5PANIg96SmAWF4VdxNPhmyu2jHkeEM=",
      "url": "assets/images/flags/sy.svg"
    },
    {
      "hash": "sha256-NJPw0wjmRuaqGPPH29+NKPgAhQhChsOz6WiJXzAyqcg=",
      "url": "assets/images/flags/sz.svg"
    },
    {
      "hash": "sha256-0R4eRVflx/igdM1CjGfd/kiTUQSGgbDbr4eFzQ2KLJ4=",
      "url": "assets/images/flags/ta.svg"
    },
    {
      "hash": "sha256-pD8wUhj6JawCHtLTyQiK1kwYfSIRrJlXQMRTR1Xn3aE=",
      "url": "assets/images/flags/tc.svg"
    },
    {
      "hash": "sha256-rwcU+QaDUKE4fcJZ449pQeMAAReh3JhkVLOfoJQLgQc=",
      "url": "assets/images/flags/td.svg"
    },
    {
      "hash": "sha256-UxR2slyOPR2jpvT9P63fPmXTeXtzIBLu9sFNHq546z8=",
      "url": "assets/images/flags/tf.svg"
    },
    {
      "hash": "sha256-vNO6AosrOIk5+FENoUFzevON28VyzJG8+fpc5eoxyYY=",
      "url": "assets/images/flags/tg.svg"
    },
    {
      "hash": "sha256-vmBiYpp+ZbOjp8VyoqS+rbyq+NEBAHZz1KAuFnyw2bo=",
      "url": "assets/images/flags/th.svg"
    },
    {
      "hash": "sha256-Eh9C/YMXCvHsRLBKxjYLwIk4I1PE19rSwULxiQx0HL4=",
      "url": "assets/images/flags/tj.svg"
    },
    {
      "hash": "sha256-xfVYEzUi1BT1xcnwtAGQ4Eq0+9lsKLg35qaO+0/kvFo=",
      "url": "assets/images/flags/tk.svg"
    },
    {
      "hash": "sha256-6x/fsS1QdwmRwjpSVbN8djA3PH6raH3jGVTNjwyiafY=",
      "url": "assets/images/flags/tl.svg"
    },
    {
      "hash": "sha256-DJoiB03rhLTn3/5uEKYRSzfHJS8CPzTnKAdK1Q7CedU=",
      "url": "assets/images/flags/tm.svg"
    },
    {
      "hash": "sha256-iiMggs8BO9dzyyQQuAcDveeBhvZediXpm45Vq+sJ37g=",
      "url": "assets/images/flags/tn.svg"
    },
    {
      "hash": "sha256-KDUDJ57E00HX0AuSX0UbFml4NkEHmt/AejW8lAsz+zA=",
      "url": "assets/images/flags/to.svg"
    },
    {
      "hash": "sha256-9UP6Xpqc7HozHoa/f30hLvXtnK8cYbY8AQw86If2Xz0=",
      "url": "assets/images/flags/tr.svg"
    },
    {
      "hash": "sha256-c/KncwztkTv4e0EkMFxMEuICHzA1gmJl7+euhhlTllE=",
      "url": "assets/images/flags/tt.svg"
    },
    {
      "hash": "sha256-5kvP+LfgZQ9qe/71OZt71SgXn3oJLO8bAodhPUu8YDY=",
      "url": "assets/images/flags/tv.svg"
    },
    {
      "hash": "sha256-XlyWk45yhAXmCUG8SrQX3vKrrusJuMd++adp31d0oek=",
      "url": "assets/images/flags/tw.svg"
    },
    {
      "hash": "sha256-Lc1OE19wVLx8jJUwxm7iKpqCZNvYO2jiWMdMBA8k2FQ=",
      "url": "assets/images/flags/tz.svg"
    },
    {
      "hash": "sha256-+EGbSaxkjF7c8m+xqUOpHB8gfDnuZ7vfsNDBU4C/Pq4=",
      "url": "assets/images/flags/ua.svg"
    },
    {
      "hash": "sha256-WbE2K+kb8caLOmDvUgME39HyWlrhxPAvZzgbhHWRNUg=",
      "url": "assets/images/flags/ug.svg"
    },
    {
      "hash": "sha256-mZ2sbneNhmdKus09yf75cj76J0BITdAJRZ0UVI15mJU=",
      "url": "assets/images/flags/um.svg"
    },
    {
      "hash": "sha256-E0gI57xjJITiWZSsAzot0TZvWiFdnp692/IhmPwPY7c=",
      "url": "assets/images/flags/un.svg"
    },
    {
      "hash": "sha256-mTqHeuoAtz7uZ4iDew42OropfZv1Z1HxRi+/KIvLFng=",
      "url": "assets/images/flags/us.svg"
    },
    {
      "hash": "sha256-CXUCX8TZyRyHdfng8/YFI0CPk2DVqj3l2HzSkrWvKSI=",
      "url": "assets/images/flags/uy.svg"
    },
    {
      "hash": "sha256-uoMXIPjtH+Q16Y9XDp0F7bVEFevJvsPJftRslee/r6k=",
      "url": "assets/images/flags/uz.svg"
    },
    {
      "hash": "sha256-S3JFGVhJ5AJRYu2L6mqNQx2+HNsk5c+gCMoBcYOOBx8=",
      "url": "assets/images/flags/va.svg"
    },
    {
      "hash": "sha256-jtzrLuSP8n0244o5NEgxuOjAhNjXFM5EYbMcW01av64=",
      "url": "assets/images/flags/vc.svg"
    },
    {
      "hash": "sha256-uMI4KuFNKRNCoxqjjci0zZfRsJlsLAUVxRX9Q4DYYWw=",
      "url": "assets/images/flags/ve.svg"
    },
    {
      "hash": "sha256-DtiwnDGVJbdbyMjyhCZPBjJcXvoVDp6lwz+K2NBmTRk=",
      "url": "assets/images/flags/vg.svg"
    },
    {
      "hash": "sha256-tWgsVkBoHpS5pMDQHmrr8zryhJXvo4hlFJf2++vGeKk=",
      "url": "assets/images/flags/vi.svg"
    },
    {
      "hash": "sha256-Ws0ZH/923mmKF0B2xTfLGZd8O0vTyP6w9DzSIQ8rwY4=",
      "url": "assets/images/flags/vn.svg"
    },
    {
      "hash": "sha256-YyYe5fdhyKtQWMToSQRuwcEcmLcumILF3trdzN4jp08=",
      "url": "assets/images/flags/vu.svg"
    },
    {
      "hash": "sha256-ogB/CR0JamLB1f4avimdgmyNda1MW8j/+STqETsVnYc=",
      "url": "assets/images/flags/wf.svg"
    },
    {
      "hash": "sha256-2PMc07oKkSJ0vebgY7quoMdU9CDnyKgf144rNBzNoe4=",
      "url": "assets/images/flags/ws.svg"
    },
    {
      "hash": "sha256-k1NXVBYRdwB3hiDCwbEJXD64xyLha6nANespisO6OQ0=",
      "url": "assets/images/flags/xk.svg"
    },
    {
      "hash": "sha256-ytYXFd6W9vA3ylLbcqkyem7UKigSAiBObdk8kUrkptA=",
      "url": "assets/images/flags/xx.svg"
    },
    {
      "hash": "sha256-JOVIgEPUThdc/Qz7dz7gCVDEBcw6n61ywFKLIQj6dyM=",
      "url": "assets/images/flags/ye.svg"
    },
    {
      "hash": "sha256-p3ekvUzhHnSfdPt8+I4olYdO0qrO38MC+OnUL/pDk3I=",
      "url": "assets/images/flags/yt.svg"
    },
    {
      "hash": "sha256-SwPyGIHd6zyHBnsDK560RRfwVcIaAY7oV0v4+X0rUfE=",
      "url": "assets/images/flags/za.svg"
    },
    {
      "hash": "sha256-ptD8B6Sy+NrxY3UkUmG/nUVhoQKTXebMS5t8kPm39EQ=",
      "url": "assets/images/flags/zm.svg"
    },
    {
      "hash": "sha256-v+tca23PWjxP/AJ2l06BFdBRwFrWqZ1a9D837DLSv3Q=",
      "url": "assets/images/flags/zw.svg"
    },
    {
      "hash": "sha256-dsKmNXsJjcNWx0nqpwWQ52KjC6Fcv62ktx4/vcQ6iAA=",
      "url": "assets/manifest/manifest-128.png"
    },
    {
      "hash": "sha256-WybxmCXlR8jvzkm1vDel2kU8/bp4jy5CSgq5okLl+Yo=",
      "url": "assets/manifest/manifest-256.png"
    },
    {
      "hash": "sha256-7rxxQe9Nq2pNb/khYlJM/ZaKhvt3ZHST5WMyv5m4FwI=",
      "url": "assets/manifest/manifest-48.png"
    },
    {
      "hash": "sha256-vqnC4Q5X3aNOvD+Kh+7rgST2bSw4x5+4tol4gznMwck=",
      "url": "assets/manifest/manifest-512.png"
    },
    {
      "hash": "sha256-GPPYMXiKAeO7YEXRtNP16dDJ3g9tJB6RQQdiWrDBAbg=",
      "url": "assets/manifest/manifest-512.svg"
    },
    {
      "hash": "sha256-pHQDZs7dmWZ6Dkw4ynepAi95Tpt9rYNp+bCPaMQvsuY=",
      "url": "assets/manifest/manifest-96.png"
    },
    {
      "hash": "sha256-Tf9jgKb8hxAp/aLYE0EuQWVp10szX5UUalXhFVGWeRg=",
      "url": "assets/symbols/msgkinds.svg"
    },
    {
      "hash": "sha256-O22DXRUlNV1pc/nuezVWX6g+AtaYlKof78YwRV3vJOo=",
      "url": "assets/symbols/symbols.svg"
    },
    {
      "hash": "sha256-bim0c7D3nFb3BV3i/fzDlZPjT5pCfPJGt6gIFbkYQV8=",
      "url": "css/_radzen-fix.css"
    },
    {
      "hash": "sha256-ndNbTJhnfIQPzZsWFa9u3PMvIhVQoOpiUtML05Ev/ac=",
      "url": "css/animations.css"
    },
    {
      "hash": "sha256-SmjiIUcPtEktLejf/i5dcyag4JS/5VGiVmITBH3s4ks=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-dsrVrfQ8N/l8LLjj4OvwhTIdrAK38AV22TvgZROKGJ8=",
      "url": "index.html"
    },
    {
      "hash": "sha256-g0IxWXcSZ4I0ujMG9VWv9SnfKWRljo+Iz/LmvFXTQds=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-R8rz9WVFkXI6mLi+9LHZiKd1KN2bXDxckwiJFkmiCDg=",
      "url": "script/appdb.js"
    },
    {
      "hash": "sha256-JNbE7qMMWxUqXJ6h+TvT2af37vZf3omkfWianP4GENw=",
      "url": "script/bookrt.js"
    },
    {
      "hash": "sha256-uGPLMA87lGZHjQf7p2mzDGRv6Yx4pbGmBVdPfzFaqQQ=",
      "url": "script/bridge.js"
    },
    {
      "hash": "sha256-kr+oFlBj7DJB8/EAc7nuLFISpAiblVD/E/k+7rvhuA0=",
      "url": "script/install-worker.3f21c39b.js"
    },
    {
      "hash": "sha256-lODwn1ICz8BJEu8g/eMt3Fq1BiePTM9qnjQGbjoGQ8Y=",
      "url": "script/reg-agent.js"
    },
    {
      "hash": "sha256-RA29NyfKz2b9S/S7WSPEpBto9PM3PhQL0yL8/dLhN2A=",
      "url": "script/sw.js"
    },
    {
      "hash": "sha256-b8oqtzwfeNGY5p/yt7g128ppCFk+cEIbbM82JQ+9xNQ=",
      "url": "script/uninstall-worker.ff2a2ab0.js"
    },
    {
      "hash": "sha256-6FBiu/ex3pOh7pGZLXwkixGaqJrXVnJXWq6bvH4MLzk=",
      "url": "script/zip.7833d543.js"
    },
    {
      "hash": "sha256-4duCMP/i2o0p2FkjwuN5SkCcmaDCah44hgtxQxoudf8=",
      "url": "vendor/bootstrap/bootstrap.min.css"
    },
    {
      "hash": "sha256-/A/GdzdN+eLbCTLdf8wURUTLuubOtZ9eTvvleFLAF80=",
      "url": "vendor/h5p/fonts/h5p-core-30.woff2"
    },
    {
      "hash": "sha256-w/PpackG3S++feD5SGrzISE/FCk2PhW16UorxymlY98=",
      "url": "vendor/h5p/fonts/h5p-hub-publish.woff2"
    },
    {
      "hash": "sha256-lZHIxMboo6kPVK/7P8GXDPXpa4LAnL5dCHoDXpXUL/w=",
      "url": "vendor/h5p/fonts/h5p-theme.woff2"
    },
    {
      "hash": "sha256-b3UCWFb42xshhunLib6d6YlJMsi3sg9N9eZZFv9xTjQ=",
      "url": "vendor/h5p/fonts/inter/Inter-ExtraBold.woff2"
    },
    {
      "hash": "sha256-U7sguikuKsKKB3e/D1bzG5i+Qyo8wENZ4utgjHWDScc=",
      "url": "vendor/h5p/fonts/inter/Inter-ExtraBoldItalic.woff2"
    },
    {
      "hash": "sha256-JiSB6ERSGzJvXs0FPlm5jIstp4yO4b27boF0MF5Uk1o=",
      "url": "vendor/h5p/fonts/inter/LICENSE.txt"
    },
    {
      "hash": "sha256-Rq7ljPJz3z7bsZ5E22beWocQb+ZB9X4IVz5iaIdXoAM=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-600.woff2"
    },
    {
      "hash": "sha256-66MeHa8tYi9nlYY15TFiBI8TVsFWVcUDuY1uzbav1VM=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-600italic.woff2"
    },
    {
      "hash": "sha256-CdVUqyfhsCziXW9fr3Hi4H53wovrQBnbz81D7HVY098=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-italic.woff2"
    },
    {
      "hash": "sha256-IatOkaYrHIba972jgY+M8HIfkc1mSp0TWSPB7WtpTpA=",
      "url": "vendor/h5p/fonts/inter/inter-v18-cyrillic_cyrillic-ext_greek_greek-ext_latin_latin-ext_vietnamese-regular.woff2"
    },
    {
      "hash": "sha256-Ac1f+zpSjCGahuSagUxsU72KabmjwwXdI3B0uhyBGvc=",
      "url": "vendor/h5p/fonts/open-sans/OFL.txt"
    },
    {
      "hash": "sha256-MgKHgtn3J6NAc11SerMJ41oTKWJ70PRRPn7U5FGog1k=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-600.woff2"
    },
    {
      "hash": "sha256-lOjKDm7udP+H30Jx/zqARBTwtE1Td/TszUjWjxfO82w=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-600italic.woff2"
    },
    {
      "hash": "sha256-c+qpgwgjhV8VbNTgsn5wlvfmI7oCa7U2ZkD7BUDN0IE=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-700.woff2"
    },
    {
      "hash": "sha256-q2UUw/DKZ4I53wFGbDqjTjjwBuPNoBakCM//CcxxxQc=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-700italic.woff2"
    },
    {
      "hash": "sha256-5NyaoE2YGfxDRayVRIMSePP/2P9K+EARmajI10Esw1M=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-italic.woff2"
    },
    {
      "hash": "sha256-YWuYcGsCsnROD1HfvgcMVr/G5z4JY7AgDpkI+Fam494=",
      "url": "vendor/h5p/fonts/open-sans/open-sans-v40-cyrillic_cyrillic-ext_greek_greek-ext_hebrew_latin_latin-ext_math_symbols_vietnamese-regular.woff2"
    },
    {
      "hash": "sha256-5t6zni0BFIaQgLrN9AktyzDPLOIPi948O6ivA1+obgs=",
      "url": "vendor/h5p/frame.bundle.js"
    },
    {
      "hash": "sha256-uOxMrprtoVTGhyYokeiQQUTeV/+fJb5it4KIvy0kaU4=",
      "url": "vendor/h5p/images/h5p.svg"
    },
    {
      "hash": "sha256-58ZlXJpC6HJzqtnreQET23N85fEaHAdsInhYT1Kkc70=",
      "url": "vendor/h5p/images/throbber.gif"
    },
    {
      "hash": "sha256-akaLwIre1F7/5MydXeFstCLmBKeicnV8EH2bh9ul9Q0=",
      "url": "vendor/h5p/styles/h5p-fonts.css"
    },
    {
      "hash": "sha256-vRzlwZyBOSdosKPaI4LCmMWTV0PZA5Gk9ZG5Sb+Q+dw=",
      "url": "vendor/h5p/styles/h5p.css"
    },
    {
      "hash": "sha256-1CldwzdEg2k1wTmf7s5RWVd7NMXI/7nxxjJM2C4DqII=",
      "url": "vendor/mathjax/tex-svg.js"
    }
  ]
};
